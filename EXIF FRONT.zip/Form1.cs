﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Infragistics.Win.Misc;
using System.Drawing;
using System.Drawing.Drawing2D;
using $safeprojectname$.Logica;
using System.Security.Cryptography;
using System.Text;
using BCrypt.Net;

namespace $safeprojectname$
{
    public partial class Form1 : Form
    {
        Feeds.Feed_Pricipal.FeedPrincipal FeedPrincipal;
        private readonly UsuarioService usuarioService;
        public Form1()
        {
            FeedPrincipal = new Feeds.Feed_Pricipal.FeedPrincipal();
            InitializeComponent();
            usuarioService = new UsuarioService();

        }

        private async Task<bool> IniciarSesion()
        {
            try
            {
                if (int.TryParse(ultraTextEditor3.Text, out int idUsuario))
                {
                    string passwordIngresada = ultraTextEditor1.Text;

                    // Llama al método para obtener el usuario por ID
                    Usuario usuario = await usuarioService.ObtenerUsuarioPorIdAsync(idUsuario);

                    // Verifica si el usuario existe
                    if (usuario != null)
                    {
                        // Utiliza VerifyPassword para comparar la contraseña ingresada con el hash almacenado
                        if (BCrypt.Net.BCrypt.Verify(passwordIngresada, usuario.Pass))
                        {
                            // Inicio de sesión exitoso
                            return true;
                        }
                        else
                        {
                            // Contraseña incorrecta
                            return false;
                        }
                    }
                    else
                    {
                        // Usuario no encontrado
                        return false;
                    }
                }
                else
                {
                    // ID de usuario inválido
                    return false;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ocurrió un error durante el inicio de sesión: {ex.Message}");
                return false;
            }
        }
        public string Hash(string password)
        {
            return BCrypt.Net.BCrypt.HashPassword(password);
        }



        private void ultraPanel1_Paint(object sender, PaintEventArgs e)
        {
          
        }

        private async void brn_loging_Click(object sender, EventArgs e)
        {
            bool inicioSesionExitoso = await IniciarSesion();

            if (inicioSesionExitoso)
            {
                // Inicio de sesión exitoso, abre el feed general
                FeedPrincipal.Show();
                this.Hide();
            }
            else
            {
                // Inicio de sesión fallido, muestra un mensaje de error
                MessageBox.Show("Error: Usuario o contraseña incorrectos.", "Inicio de Sesión Fallido", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }

        private void ultraPanel1_PaintClient(object sender, PaintEventArgs e)
        {

        }
    }
}
