﻿
namespace $safeprojectname$
{
    partial class Registro
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Infragistics.Win.Appearance appearance1 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance2 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance3 = new Infragistics.Win.Appearance();
            this.ultraPanel1 = new Infragistics.Win.Misc.UltraPanel();
            this.ultraPanel2 = new Infragistics.Win.Misc.UltraPanel();
            this.btn_publicar = new System.Windows.Forms.Button();
            this.btn_feed_ajuste = new System.Windows.Forms.Button();
            this.btn_Feed_mod = new System.Windows.Forms.Button();
            this.btn_Feed_Chat = new System.Windows.Forms.Button();
            this.btn_Feed_Grupo = new System.Windows.Forms.Button();
            this.btn_Feed_General = new System.Windows.Forms.Button();
            this.ultraPanel3 = new Infragistics.Win.Misc.UltraPanel();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.ultraPanel1.ClientArea.SuspendLayout();
            this.ultraPanel1.SuspendLayout();
            this.ultraPanel2.ClientArea.SuspendLayout();
            this.ultraPanel2.SuspendLayout();
            this.ultraPanel3.SuspendLayout();
            this.SuspendLayout();
            // 
            // ultraPanel1
            // 
            appearance1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            appearance1.BackColor2 = System.Drawing.Color.Navy;
            appearance1.BackColorDisabled = System.Drawing.Color.White;
            appearance1.BackGradientAlignment = Infragistics.Win.GradientAlignment.Form;
            appearance1.BackGradientStyle = Infragistics.Win.GradientStyle.BackwardDiagonal;
            this.ultraPanel1.Appearance = appearance1;
            this.ultraPanel1.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            // 
            // ultraPanel1.ClientArea
            // 
            this.ultraPanel1.ClientArea.Controls.Add(this.textBox1);
            this.ultraPanel1.ClientArea.Controls.Add(this.ultraPanel2);
            this.ultraPanel1.Location = new System.Drawing.Point(-13, -95);
            this.ultraPanel1.Name = "ultraPanel1";
            this.ultraPanel1.Size = new System.Drawing.Size(1036, 817);
            this.ultraPanel1.TabIndex = 2;
            // 
            // ultraPanel2
            // 
            appearance2.BackColor = System.Drawing.Color.LightSeaGreen;
            appearance2.BackColor2 = System.Drawing.Color.SteelBlue;
            appearance2.BackGradientAlignment = Infragistics.Win.GradientAlignment.Element;
            appearance2.BackGradientStyle = Infragistics.Win.GradientStyle.ForwardDiagonal;
            appearance2.BackHatchStyle = Infragistics.Win.BackHatchStyle.None;
            appearance2.BorderColor = System.Drawing.Color.Transparent;
            this.ultraPanel2.Appearance = appearance2;
            // 
            // ultraPanel2.ClientArea
            // 
            this.ultraPanel2.ClientArea.Controls.Add(this.btn_publicar);
            this.ultraPanel2.ClientArea.Controls.Add(this.btn_feed_ajuste);
            this.ultraPanel2.ClientArea.Controls.Add(this.btn_Feed_mod);
            this.ultraPanel2.ClientArea.Controls.Add(this.btn_Feed_Chat);
            this.ultraPanel2.ClientArea.Controls.Add(this.btn_Feed_Grupo);
            this.ultraPanel2.ClientArea.Controls.Add(this.btn_Feed_General);
            this.ultraPanel2.ClientArea.Controls.Add(this.ultraPanel3);
            this.ultraPanel2.Location = new System.Drawing.Point(3, 94);
            this.ultraPanel2.Name = "ultraPanel2";
            this.ultraPanel2.Size = new System.Drawing.Size(1019, 38);
            this.ultraPanel2.TabIndex = 0;
            // 
            // btn_publicar
            // 
            this.btn_publicar.BackColor = System.Drawing.Color.Transparent;
            this.btn_publicar.BackgroundImage = global::$safeprojectname$.Properties.Resources.mdi__post_it_note_add;
            this.btn_publicar.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btn_publicar.Cursor = System.Windows.Forms.Cursors.Default;
            this.btn_publicar.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_publicar.ForeColor = System.Drawing.Color.Transparent;
            this.btn_publicar.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btn_publicar.Location = new System.Drawing.Point(215, 4);
            this.btn_publicar.Name = "btn_publicar";
            this.btn_publicar.Size = new System.Drawing.Size(30, 31);
            this.btn_publicar.TabIndex = 6;
            this.btn_publicar.UseVisualStyleBackColor = false;
            // 
            // btn_feed_ajuste
            // 
            this.btn_feed_ajuste.BackColor = System.Drawing.Color.Transparent;
            this.btn_feed_ajuste.BackgroundImage = global::$safeprojectname$.Properties.Resources.mdi__settings_stop;
            this.btn_feed_ajuste.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btn_feed_ajuste.Cursor = System.Windows.Forms.Cursors.Default;
            this.btn_feed_ajuste.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_feed_ajuste.ForeColor = System.Drawing.Color.Transparent;
            this.btn_feed_ajuste.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btn_feed_ajuste.Location = new System.Drawing.Point(975, 3);
            this.btn_feed_ajuste.Name = "btn_feed_ajuste";
            this.btn_feed_ajuste.Size = new System.Drawing.Size(30, 31);
            this.btn_feed_ajuste.TabIndex = 5;
            this.btn_feed_ajuste.UseVisualStyleBackColor = false;
            // 
            // btn_Feed_mod
            // 
            this.btn_Feed_mod.BackColor = System.Drawing.Color.Transparent;
            this.btn_Feed_mod.BackgroundImage = global::$safeprojectname$.Properties.Resources.mdi__mode_edit;
            this.btn_Feed_mod.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btn_Feed_mod.Cursor = System.Windows.Forms.Cursors.Default;
            this.btn_Feed_mod.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_Feed_mod.ForeColor = System.Drawing.Color.Transparent;
            this.btn_Feed_mod.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btn_Feed_mod.Location = new System.Drawing.Point(168, 4);
            this.btn_Feed_mod.Name = "btn_Feed_mod";
            this.btn_Feed_mod.Size = new System.Drawing.Size(30, 31);
            this.btn_Feed_mod.TabIndex = 4;
            this.btn_Feed_mod.UseVisualStyleBackColor = false;
            // 
            // btn_Feed_Chat
            // 
            this.btn_Feed_Chat.BackColor = System.Drawing.Color.Transparent;
            this.btn_Feed_Chat.BackgroundImage = global::$safeprojectname$.Properties.Resources.mdi__message_group;
            this.btn_Feed_Chat.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btn_Feed_Chat.Cursor = System.Windows.Forms.Cursors.Default;
            this.btn_Feed_Chat.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_Feed_Chat.ForeColor = System.Drawing.Color.Transparent;
            this.btn_Feed_Chat.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btn_Feed_Chat.Location = new System.Drawing.Point(116, 4);
            this.btn_Feed_Chat.Name = "btn_Feed_Chat";
            this.btn_Feed_Chat.Size = new System.Drawing.Size(30, 31);
            this.btn_Feed_Chat.TabIndex = 3;
            this.btn_Feed_Chat.UseVisualStyleBackColor = false;
            // 
            // btn_Feed_Grupo
            // 
            this.btn_Feed_Grupo.BackColor = System.Drawing.Color.Transparent;
            this.btn_Feed_Grupo.BackgroundImage = global::$safeprojectname$.Properties.Resources.mdi__account_group;
            this.btn_Feed_Grupo.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btn_Feed_Grupo.Cursor = System.Windows.Forms.Cursors.Default;
            this.btn_Feed_Grupo.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_Feed_Grupo.ForeColor = System.Drawing.Color.Transparent;
            this.btn_Feed_Grupo.Image = global::$safeprojectname$.Properties.Resources.mdi__account_group;
            this.btn_Feed_Grupo.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btn_Feed_Grupo.Location = new System.Drawing.Point(66, 4);
            this.btn_Feed_Grupo.Name = "btn_Feed_Grupo";
            this.btn_Feed_Grupo.Size = new System.Drawing.Size(30, 31);
            this.btn_Feed_Grupo.TabIndex = 2;
            this.btn_Feed_Grupo.UseVisualStyleBackColor = false;
            // 
            // btn_Feed_General
            // 
            this.btn_Feed_General.BackColor = System.Drawing.Color.Transparent;
            this.btn_Feed_General.BackgroundImage = global::$safeprojectname$.Properties.Resources.mdi__post_outline;
            this.btn_Feed_General.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btn_Feed_General.Cursor = System.Windows.Forms.Cursors.Default;
            this.btn_Feed_General.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_Feed_General.ForeColor = System.Drawing.Color.Transparent;
            this.btn_Feed_General.Image = global::$safeprojectname$.Properties.Resources.mdi__post_outline;
            this.btn_Feed_General.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btn_Feed_General.Location = new System.Drawing.Point(19, 4);
            this.btn_Feed_General.Name = "btn_Feed_General";
            this.btn_Feed_General.Size = new System.Drawing.Size(30, 31);
            this.btn_Feed_General.TabIndex = 1;
            this.btn_Feed_General.UseVisualStyleBackColor = false;
            // 
            // ultraPanel3
            // 
            appearance3.BackColor = System.Drawing.Color.Black;
            this.ultraPanel3.Appearance = appearance3;
            this.ultraPanel3.Font = new System.Drawing.Font("Microsoft Sans Serif", 1.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ultraPanel3.Location = new System.Drawing.Point(3, 36);
            this.ultraPanel3.Name = "ultraPanel3";
            this.ultraPanel3.Size = new System.Drawing.Size(1019, 2);
            this.ultraPanel3.TabIndex = 1;
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(216, 285);
            this.textBox1.MaxLength = 12;
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(100, 20);
            this.textBox1.TabIndex = 1;
            // 
            // Registro
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1010, 626);
            this.Controls.Add(this.ultraPanel1);
            this.Name = "Registro";
            this.Text = "Registro";
            this.ultraPanel1.ClientArea.ResumeLayout(false);
            this.ultraPanel1.ClientArea.PerformLayout();
            this.ultraPanel1.ResumeLayout(false);
            this.ultraPanel2.ClientArea.ResumeLayout(false);
            this.ultraPanel2.ResumeLayout(false);
            this.ultraPanel3.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private Infragistics.Win.Misc.UltraPanel ultraPanel1;
        private Infragistics.Win.Misc.UltraPanel ultraPanel2;
        private System.Windows.Forms.Button btn_publicar;
        private System.Windows.Forms.Button btn_feed_ajuste;
        private System.Windows.Forms.Button btn_Feed_mod;
        private System.Windows.Forms.Button btn_Feed_Chat;
        private System.Windows.Forms.Button btn_Feed_Grupo;
        private System.Windows.Forms.Button btn_Feed_General;
        private Infragistics.Win.Misc.UltraPanel ultraPanel3;
        private System.Windows.Forms.TextBox textBox1;
    }
}