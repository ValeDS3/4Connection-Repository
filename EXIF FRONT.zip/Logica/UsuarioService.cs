﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace $safeprojectname$.Logica
{
    public class UsuarioService
    {
        private readonly HttpClient _httpClient;

        public UsuarioService()
        {
            _httpClient = new HttpClient();
        }

        public async Task<Usuario> ObtenerUsuarioPorIdAsync(int id)
        {
            try
            {
                // Construye la URL incluyendo el ID del usuario
                string url = $"https://localhost:44350/api/UsuarioControlador/{id}"; // Cambia por la URL de tu API y el endpoint correcto

                // Realiza la solicitud HTTP GET a la API con el ID específico
                HttpResponseMessage response = await _httpClient.GetAsync(url);

                // Verifica si la respuesta es exitosa
                response.EnsureSuccessStatusCode();

                // Lee el contenido de la respuesta como string
                string responseBody = await response.Content.ReadAsStringAsync();

                // Deserializa el JSON en un objeto de tipo Usuario y lo devuelve
                Usuario usuario = JsonConvert.DeserializeObject<Usuario>(responseBody);

                return usuario;
            }
            catch (HttpRequestException e)
            {
                Console.WriteLine($"Error al obtener el usuario con ID {id}: {e.Message}");
                return null;
            }
        }

        public async Task<int?> AgregarUsuario(string nombre, string fechaNac, string descripcion, byte[] fotoPerfil, string pass)
        {
            string api = "https://localhost:44350/api/UsuarioControlador/CrearUsuario";
            using (HttpClient client = new HttpClient())
            {
                try
                {
                    using (var content = new MultipartFormDataContent())
                    {
                        // Agregar datos de texto
                        content.Add(new StringContent(nombre), "Nombre");
                        content.Add(new StringContent(fechaNac), "FechaNac");
                        content.Add(new StringContent(descripcion), "Descripcion");
                        content.Add(new StringContent(pass), "Pass");  // Asegúrate de agregar la contraseña correctamente

                        // Agregar la imagen como archivo
                        if (fotoPerfil != null)
                        {
                            var imageContent = new ByteArrayContent(fotoPerfil);
                            imageContent.Headers.ContentType = System.Net.Http.Headers.MediaTypeHeaderValue.Parse("image/png");
                            content.Add(imageContent, "FotoPerfil", "fotoPerfil.png");
                        }

                        HttpResponseMessage response = await client.PostAsync(api, content);

                        if (response.IsSuccessStatusCode)
                        {
                            string responseContent = await response.Content.ReadAsStringAsync();
                            var responseData = JsonConvert.DeserializeObject<dynamic>(responseContent);
                            int id = responseData.id;
                            Console.WriteLine($"Usuario agregado correctamente con ID: {id}");
                            return id;
                        }
                        else
                        {
                            string responseContent = await response.Content.ReadAsStringAsync();
                            Console.WriteLine($"Error al agregar el usuario: {response.StatusCode} - {responseContent}");
                            return null;
                        }
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Excepción al agregar usuario: {ex.Message}");
                    return null;
                }
            }
        }

        public async Task<bool> ActualizarUsuario(int idUsuario, string nombre, string fechaNac, string descripcion, byte[] fotoPerfil, string pass)
        {
            string url = $"https://localhost:44350/api/UsuarioControlador/ActualizarUsuario"; // Asegúrate de que la URL es correcta

            try
            {
                using (var content = new MultipartFormDataContent())
                {
                    content.Add(new StringContent(nombre), "Nombre");
                    content.Add(new StringContent(fechaNac), "FechaNac");
                    content.Add(new StringContent(descripcion), "Descripcion");
                    content.Add(new StringContent(pass), "Pass");

                    // Agregar la imagen como archivo
                    if (fotoPerfil != null && fotoPerfil.Length > 0)
                    {
                        var imageContent = new ByteArrayContent(fotoPerfil);
                        imageContent.Headers.ContentType = new System.Net.Http.Headers.MediaTypeHeaderValue("application/octet-stream");
                        content.Add(imageContent, "FotoPerfil", "fotoPerfil.png");
                    }

                    // Enviar la solicitud PUT
                    HttpResponseMessage response = await _httpClient.PutAsync(url, content);

                    // Comprobar si la solicitud fue exitosa
                    if (response.IsSuccessStatusCode)
                    {
                        return true; // Retorna verdadero si la actualización fue exitosa
                    }
                    else
                    {
                        Console.WriteLine($"Error al actualizar el usuario: {response.StatusCode}");
                        return false; // Retorna falso si ocurrió un error
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Excepción al actualizar el usuario: {ex.Message}");
                return false;
            }
        }


        public async Task<bool> EliminarUsuario(int idusuarioE)
        {
            string url = $"https://localhost:44350/api/UsuarioControlador/{idusuarioE}"; 

            try
            {
                // Realiza la solicitud HTTP DELETE a la API
                HttpResponseMessage response = await _httpClient.DeleteAsync(url);

                // Comprobar si la solicitud fue exitosa
                if (response.IsSuccessStatusCode)
                {
                    Console.WriteLine("Usuario eliminado correctamente.");
                    return true; // Retorna verdadero si la eliminación fue exitosa
                }
                else
                {
                    Console.WriteLine($"Error al eliminar el usuario: {response.StatusCode}");
                    return false; // Retorna falso si ocurrió un error
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Excepción al eliminar el usuario: {ex.Message}");
                return false;
            }
        }




    }
}
