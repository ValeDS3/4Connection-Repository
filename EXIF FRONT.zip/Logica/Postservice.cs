﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;

namespace $safeprojectname$.Logica
{
   public class Postservice
    {
        private readonly string apiPost = "https://localhost:44381/api/PostControlador";
        private readonly string apiPostImagen= "https://localhost:44381/api/PostImagenControlador";

        public async Task<List<Post>> ObtenerPostsAsync()
        {
            using (HttpClient client = new HttpClient())
            {
                var response = await client.GetAsync($"{apiPost}");
                response.EnsureSuccessStatusCode();
                
                if (response.IsSuccessStatusCode)
                {
                    string esto= await response.Content.ReadAsStringAsync();
                    return JsonConvert.DeserializeObject<List<Post>>(esto) ?? new List<Post>();
                }

                else
                {
                    throw new Exception("Error al obtener los posts.");
                }

            }
        }

        public async Task<List<byte[]>> ObtenerImagenesDePostAsync(int postId)
        {
            using (HttpClient client = new HttpClient())
            {
                var response = await client.GetAsync($"{apiPostImagen}/{postId}");
                response.EnsureSuccessStatusCode();

                if (response.IsSuccessStatusCode)
                {
                    byte[] imageData = await response.Content.ReadAsByteArrayAsync();
                    return new List<byte[]> { imageData };
                }
                else
                {
                    throw new Exception("Error al obtener la imagen para el post con ID " + postId);
                }
            }
        }

    }
}
