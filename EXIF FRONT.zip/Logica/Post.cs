﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace $safeprojectname$.Logica
{
    public class Post
    {
        public int? IdPost { get; set; }
        public int IdUsuario { get; set; }
        public string UrlVideo { get; set; }
        public string Texto { get; set; }

        public string Fecha { get; set; }
        public List<byte[]> Imagenes { get; set; } = new List<byte[]>();

    }
}
