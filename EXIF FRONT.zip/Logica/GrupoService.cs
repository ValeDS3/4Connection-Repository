﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace $safeprojectname$.Logica
{
    public class GrupoService
    {
        private readonly string apiGrupoUrl = "https://localhost:44350/api/GrupoControlador";
        private readonly HttpClient _httpClient;

        public GrupoService()
        {
            _httpClient = new HttpClient();
        }
        public async Task<List<Grupo>> ObtenerGruposAsync()
        {
            string api = "https://localhost:44350/api/GrupoControlador";
            using (HttpClient client = new HttpClient())
            {
                try
                {
                    HttpResponseMessage response = await client.GetAsync(api);
                    if (response.IsSuccessStatusCode)
                    {
                        string json = await response.Content.ReadAsStringAsync();
                        List<Grupo> grupos = JsonConvert.DeserializeObject<List<Grupo>>(json);
                        return grupos;
                    }
                    else
                    {
                        throw new Exception($"Error al obtener grupos: {response.StatusCode}");
                    }
                }
                catch (Exception ex)
                {
                    // Log the error
                    Console.WriteLine($"No se pudo conectar con la API: {ex.Message}");
                    throw; // O manejo opcional de errores
                }

            }
        }

        public async Task<Grupo> ObtenerGrupoPorIdAsync(int id)
        {

            try
            {
                string url = $"https://localhost:44350/api/GrupoControlador/{id}";
                HttpResponseMessage response = await _httpClient.GetAsync(url);
                response.EnsureSuccessStatusCode();
                string responseBody = await response.Content.ReadAsStringAsync();
                return JsonConvert.DeserializeObject<Grupo>(responseBody);
            }
            catch (HttpRequestException e)
            {
                Console.WriteLine($"Error al obtener el grupo: {e.Message}");
                return null;
            }
        }

    }
}
