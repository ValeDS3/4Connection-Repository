﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace $safeprojectname$.Logica.Login
{
    public class Usuario
    {
        public int? IdUsuario { get; set; }         // Este se generará automáticamente, no es necesario proporcionarlo
        public string Nombre { get; set; }
        public String FechaNac { get; set; }
        public byte[] FotoPerfil { get; set; }
        public string Descripcion { get; set; }
        public string Pass { get; set; }


        public Usuario() { }

        // Constructor con parámetros
        public Usuario(string nombre, string fechaNac, string descripcion, byte[] fotoPerfil)
        {
            Nombre = nombre;
            FechaNac = fechaNac;
            Descripcion = descripcion;
            FotoPerfil = fotoPerfil;
        }
    }
}
