﻿using $safeprojectname$.Logica;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace $safeprojectname$.Feeds.Feed_Grupo
{
    public partial class FeedGrupos : Form
    {
        Feed_Ajustes.FeedAjustes FeedAjustes;
        Feed_Chat.FeedChat FeedChat;
        Feed_Modificar.Feed_Modificar Feed_Modificar;
        Feed_Publicar.Feed_publicar Feed_Publicar;
        Feed_General.FeedGeneral FeedGeneral;
        private readonly GrupoService grupoService = new GrupoService();
        private int currentGrupoIndex = 0;
        private List<Grupo> grupos = new List<Grupo>();
        

        public FeedGrupos()
        {
            InitializeComponent();
            grupoService = new GrupoService();

            // Asegúrate de que los botones están correctamente configurados
            button1.Text = "Anterior";
            button1.Location = new Point(10, 10);  // Ajusta según sea necesario
            button1.Click += (s, e) => MostrarGrupoAnterior();

            button2.Text = "Siguiente";
            button2.Location = new Point(110, 10);  // Ajusta según sea necesario
            button2.Click += (s, e) => MostrarGrupoSiguiente();

            this.Controls.Add(button1);
            this.Controls.Add(button2);

            Load += async (s, e) => await CargarGruposAsync();

        }
        private async Task CargarGruposAsync()
        {


            try
            {
                grupos = await grupoService.ObtenerGruposAsync() ?? new List<Grupo>();

                if (grupos.Count == 0)
                {
                    MessageBox.Show("No se encontraron grupos.");
                    return;
                }

                // Muestra el primer grupo en la lista
                MostrarGrupo(currentGrupoIndex);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error al cargar los grupos: {ex.Message}");
            }

        }
        private void MostrarGrupo(int index)
        {
            if (index >= 0 && index < grupos.Count)
            {
                var grupo = grupos[index];
                labelNombre.Text = grupo.NombreGrupo;
                txtcontenido.Text = grupo.Descripcion;

                // Verifica si `Pp_Grupos` tiene un valor y no es nulo
                if (!string.IsNullOrEmpty(grupo.PpGrupos))
                {
                    try
                    {
                        // Convierte el string Base64 a un arreglo de bytes
                        byte[] imagenBytes = Convert.FromBase64String(grupo.PpGrupos);

                        // Convierte el arreglo de bytes a una imagen
                        using (var ms = new MemoryStream(imagenBytes))
                        {
                            pictureBox1.Image = Image.FromStream(ms);
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show($"Error al cargar la imagen: {ex.Message}");
                        pictureBox1.Image = null; // Limpia la imagen si ocurre un error
                    }
                }
                else
                {
                    pictureBox1.Image = null; // Limpia la imagen si no hay datos
                }
            }
        }

        public Image ConvertirByteArrayAImagen(byte[] imagenBytes)
        {
            if (imagenBytes == null || imagenBytes.Length == 0)
                return null;

            using (var ms = new MemoryStream(imagenBytes))
            {
                return Image.FromStream(ms);
            }
        }

        private void MostrarGrupoAnterior()
        {
            if (currentGrupoIndex > 0)
            {
                currentGrupoIndex--;
                MostrarGrupo(currentGrupoIndex);
            }
            else
            {
                MessageBox.Show("Ya estás viendo el primer grupo.");
            }
        }

        private void MostrarGrupoSiguiente()
        {
            if (currentGrupoIndex < grupos.Count - 1)
            {
                currentGrupoIndex++;
                MostrarGrupo(currentGrupoIndex);
            }
            else
            {
                MessageBox.Show("Ya estás viendo el último grupo.");
            }
        }


        private void btn_Feed_General_Click(object sender, EventArgs e)
        {
            this.Close();
            if (FeedGeneral == null || FeedGeneral.IsDisposed)
            {
                FeedGeneral = new Feed_General.FeedGeneral();
                FeedGeneral.Show();
            }
            else
            {
                FeedGeneral.Show();
            }
        }

        private void btn_Feed_Grupo_Click(object sender, EventArgs e)
        {
           
        }

        private void btn_Feed_Chat_Click(object sender, EventArgs e)
        {
            this.Close();
            if (FeedChat == null || FeedChat.IsDisposed)
            {
                FeedChat = new Feed_Chat.FeedChat();
                FeedChat.Show();
            }
            else
            {
                FeedChat.Show();
            }
        }

        private void btn_Feed_mod_Click(object sender, EventArgs e)
        {
            this.Close();
            if (Feed_Modificar == null || Feed_Modificar.IsDisposed)
            {
                Feed_Modificar = new Feed_Modificar.Feed_Modificar();
                Feed_Modificar.Show();
            }
            else
            {
                Feed_Modificar.Show();
            }
        }

        private void btn_publicar_Click(object sender, EventArgs e)
        {
            this.Close();
            if (Feed_Publicar == null || Feed_Publicar.IsDisposed)
            {
                Feed_Publicar = new Feeds.Feed_Publicar.Feed_publicar();
                Feed_Publicar.Show();
            }
            else
            {
                Feed_Publicar.Show();
            }
        }

        private void btn_feed_ajuste_Click(object sender, EventArgs e)
        {
            this.Close();
            if (FeedAjustes == null || FeedAjustes.IsDisposed)
            {
                FeedAjustes = new Feed_Ajustes.FeedAjustes();
                FeedAjustes.Show();
            }
            else
            {
                FeedAjustes.Show();
            }
        }

        private void ultraLabel1_Click(object sender, EventArgs e)
        {

        }

        private void btn_crear_Click(object sender, EventArgs e)
        {

        }

        private void ultraPanel1_PaintClient(object sender, PaintEventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void button6_Click(object sender, EventArgs e)
        {

        }

        private void txtcontenido_Click(object sender, EventArgs e)
        {

        }
    }
}
