﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace $safeprojectname$.Feeds.Feed_Modificar.Modificar_opciones
{
    public partial class ModificarPerfil : Form
    {
        Feed_Ajustes.FeedAjustes FeedAjustes;
        Feed_Chat.FeedChat FeedChat;
        Feed_Grupo.FeedGrupos FeedGrupos;
        // me marca que la clase Feed_Modificar no exite y solo pasa en las ventanas e opciones  y no se porque     
        // Feed_Modificar.Feed_Modificar Feed_Modificar;
        Feed_Publicar.Feed_publicar Feed_Publicar;
        Feed_General.FeedGeneral FeedGeneral;
        public ModificarPerfil()
        {
            

            InitializeComponent();
        }

        private void btn_Feed_General_Click(object sender, EventArgs e)
        {
            this.Close();
            if (FeedGeneral == null || FeedGeneral.IsDisposed)
            {
                FeedGeneral = new Feed_General.FeedGeneral();
                FeedGeneral.Show();
            }
            else
            {
                FeedGeneral.Show();
            }

        }

        private void btn_Feed_Grupo_Click(object sender, EventArgs e)
        {
            this.Close();
            if (FeedGrupos == null || FeedGrupos.IsDisposed)
            {
                FeedGrupos = new Feed_Grupo.FeedGrupos();
                FeedGrupos.Show();
            }
            else
            {
                FeedGrupos.Show();
            }

        }

        private void btn_Feed_Chat_Click(object sender, EventArgs e)
        {
            this.Close();
            if (FeedChat == null || FeedChat.IsDisposed)
            {
                FeedChat = new Feed_Chat.FeedChat();
                FeedChat.Show();
            }
            else
            {
                FeedChat.Show();
            }

        }

        private void btn_Feed_mod_Click(object sender, EventArgs e)
        {
            
           /*this.Close();
            if (Feed_Modificar == null || Feed_Modificar.IsDisposed)
            {
                Feed_Modificar = new Feed_Modificar.Feed_Modificar();
                Feed_Modificar.Show();
            }
            else
            {
                Feed_Modificar.Show();
            }
           */
        }

        private void btn_publicar_Click(object sender, EventArgs e)
        {
            this.Close();
            if (Feed_Publicar == null || Feed_Publicar.IsDisposed)
            {
                Feed_Publicar = new Feeds.Feed_Publicar.Feed_publicar();
                Feed_Publicar.Show();
            }
            else
            {
                Feed_Publicar.Show();
            }

        }

        private void btn_feed_ajuste_Click(object sender, EventArgs e)
        {
            this.Close();
            if (FeedAjustes == null || FeedAjustes.IsDisposed)
            {
                FeedAjustes = new Feed_Ajustes.FeedAjustes();
                FeedAjustes.Show();
            }
            else
            {
                FeedAjustes.Show();
            }
        }
    }
}
