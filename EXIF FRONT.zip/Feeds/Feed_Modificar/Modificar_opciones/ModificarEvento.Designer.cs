﻿
namespace $safeprojectname$.Feeds.Feed_Modificar.Modificar_opciones
{
    partial class ModificarEvento
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Infragistics.Win.Appearance appearance1 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance2 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance3 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance4 = new Infragistics.Win.Appearance();
            this.ultraPanel1 = new Infragistics.Win.Misc.UltraPanel();
            this.button1 = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.ultraDateTimeEditor2 = new Infragistics.Win.UltraWinEditors.UltraDateTimeEditor();
            this.ultraDateTimeEditor1 = new Infragistics.Win.UltraWinEditors.UltraDateTimeEditor();
            this.label1 = new System.Windows.Forms.Label();
            this.lb_etiquetas = new System.Windows.Forms.ListBox();
            this.ultraLabel1 = new Infragistics.Win.Misc.UltraLabel();
            this.txt_URL = new System.Windows.Forms.TextBox();
            this.txt_texto_post = new System.Windows.Forms.TextBox();
            this.btn_cargar_img = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.ultraPanel2 = new Infragistics.Win.Misc.UltraPanel();
            this.btn_publicar = new System.Windows.Forms.Button();
            this.btn_feed_ajuste = new System.Windows.Forms.Button();
            this.btn_Feed_mod = new System.Windows.Forms.Button();
            this.btn_Feed_Chat = new System.Windows.Forms.Button();
            this.btn_Feed_Grupo = new System.Windows.Forms.Button();
            this.btn_Feed_General = new System.Windows.Forms.Button();
            this.ultraPanel3 = new Infragistics.Win.Misc.UltraPanel();
            this.ultraPanel1.ClientArea.SuspendLayout();
            this.ultraPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ultraDateTimeEditor2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ultraDateTimeEditor1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.ultraPanel2.ClientArea.SuspendLayout();
            this.ultraPanel2.SuspendLayout();
            this.ultraPanel3.SuspendLayout();
            this.SuspendLayout();
            // 
            // ultraPanel1
            // 
            appearance1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            appearance1.BackColor2 = System.Drawing.Color.Navy;
            appearance1.BackColorDisabled = System.Drawing.Color.White;
            appearance1.BackGradientAlignment = Infragistics.Win.GradientAlignment.Form;
            appearance1.BackGradientStyle = Infragistics.Win.GradientStyle.BackwardDiagonal;
            this.ultraPanel1.Appearance = appearance1;
            this.ultraPanel1.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            // 
            // ultraPanel1.ClientArea
            // 
            this.ultraPanel1.ClientArea.Controls.Add(this.button1);
            this.ultraPanel1.ClientArea.Controls.Add(this.label3);
            this.ultraPanel1.ClientArea.Controls.Add(this.label2);
            this.ultraPanel1.ClientArea.Controls.Add(this.ultraDateTimeEditor2);
            this.ultraPanel1.ClientArea.Controls.Add(this.ultraDateTimeEditor1);
            this.ultraPanel1.ClientArea.Controls.Add(this.label1);
            this.ultraPanel1.ClientArea.Controls.Add(this.lb_etiquetas);
            this.ultraPanel1.ClientArea.Controls.Add(this.ultraLabel1);
            this.ultraPanel1.ClientArea.Controls.Add(this.txt_URL);
            this.ultraPanel1.ClientArea.Controls.Add(this.txt_texto_post);
            this.ultraPanel1.ClientArea.Controls.Add(this.btn_cargar_img);
            this.ultraPanel1.ClientArea.Controls.Add(this.pictureBox1);
            this.ultraPanel1.ClientArea.Controls.Add(this.ultraPanel2);
            this.ultraPanel1.Location = new System.Drawing.Point(-8, -95);
            this.ultraPanel1.Name = "ultraPanel1";
            this.ultraPanel1.Size = new System.Drawing.Size(1031, 817);
            this.ultraPanel1.TabIndex = 2;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.Transparent;
            this.button1.BackgroundImage = global::$safeprojectname$.Properties.Resources.mdi__arrow_up_bold;
            this.button1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.button1.Cursor = System.Windows.Forms.Cursors.Default;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button1.ForeColor = System.Drawing.Color.Transparent;
            this.button1.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.button1.Location = new System.Drawing.Point(69, 605);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(913, 104);
            this.button1.TabIndex = 44;
            this.button1.UseVisualStyleBackColor = false;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(707, 519);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(166, 29);
            this.label3.TabIndex = 43;
            this.label3.Text = "FECHA FINAL";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(437, 519);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(171, 29);
            this.label2.TabIndex = 42;
            this.label2.Text = "FECHA INICIO";
            // 
            // ultraDateTimeEditor2
            // 
            this.ultraDateTimeEditor2.FormatProvider = new System.Globalization.CultureInfo("es-UY");
            this.ultraDateTimeEditor2.Location = new System.Drawing.Point(688, 551);
            this.ultraDateTimeEditor2.MaskInput = "{LOC}mm/dd/yyyy hh:mm:ss tt";
            this.ultraDateTimeEditor2.Name = "ultraDateTimeEditor2";
            this.ultraDateTimeEditor2.Size = new System.Drawing.Size(208, 21);
            this.ultraDateTimeEditor2.TabIndex = 41;
            // 
            // ultraDateTimeEditor1
            // 
            this.ultraDateTimeEditor1.FormatProvider = new System.Globalization.CultureInfo("es-UY");
            this.ultraDateTimeEditor1.Location = new System.Drawing.Point(419, 551);
            this.ultraDateTimeEditor1.MaskInput = "{LOC}mm/dd/yyyy hh:mm:ss tt";
            this.ultraDateTimeEditor1.Name = "ultraDateTimeEditor1";
            this.ultraDateTimeEditor1.Size = new System.Drawing.Size(208, 21);
            this.ultraDateTimeEditor1.TabIndex = 40;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(595, 374);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(134, 29);
            this.label1.TabIndex = 39;
            this.label1.Text = "ETIQUETA";
            // 
            // lb_etiquetas
            // 
            this.lb_etiquetas.FormattingEnabled = true;
            this.lb_etiquetas.Location = new System.Drawing.Point(385, 406);
            this.lb_etiquetas.Name = "lb_etiquetas";
            this.lb_etiquetas.Size = new System.Drawing.Size(550, 95);
            this.lb_etiquetas.TabIndex = 38;
            // 
            // ultraLabel1
            // 
            appearance2.BackColor = System.Drawing.Color.Transparent;
            appearance2.TextHAlignAsString = "Center";
            appearance2.TextVAlignAsString = "Bottom";
            this.ultraLabel1.Appearance = appearance2;
            this.ultraLabel1.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F);
            this.ultraLabel1.Location = new System.Drawing.Point(555, 296);
            this.ultraLabel1.Name = "ultraLabel1";
            this.ultraLabel1.Size = new System.Drawing.Size(210, 27);
            this.ultraLabel1.TabIndex = 37;
            this.ultraLabel1.Text = "URL";
            // 
            // txt_URL
            // 
            this.txt_URL.Location = new System.Drawing.Point(385, 329);
            this.txt_URL.Name = "txt_URL";
            this.txt_URL.Size = new System.Drawing.Size(550, 20);
            this.txt_URL.TabIndex = 36;
            // 
            // txt_texto_post
            // 
            this.txt_texto_post.Location = new System.Drawing.Point(385, 152);
            this.txt_texto_post.Multiline = true;
            this.txt_texto_post.Name = "txt_texto_post";
            this.txt_texto_post.Size = new System.Drawing.Size(550, 110);
            this.txt_texto_post.TabIndex = 35;
            // 
            // btn_cargar_img
            // 
            this.btn_cargar_img.BackColor = System.Drawing.Color.Transparent;
            this.btn_cargar_img.BackgroundImage = global::$safeprojectname$.Properties.Resources.mdi__post_it_note_add;
            this.btn_cargar_img.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btn_cargar_img.Cursor = System.Windows.Forms.Cursors.Default;
            this.btn_cargar_img.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_cargar_img.ForeColor = System.Drawing.Color.Transparent;
            this.btn_cargar_img.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btn_cargar_img.Location = new System.Drawing.Point(22, 507);
            this.btn_cargar_img.Name = "btn_cargar_img";
            this.btn_cargar_img.Size = new System.Drawing.Size(337, 31);
            this.btn_cargar_img.TabIndex = 34;
            this.btn_cargar_img.UseVisualStyleBackColor = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Location = new System.Drawing.Point(22, 152);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(337, 349);
            this.pictureBox1.TabIndex = 33;
            this.pictureBox1.TabStop = false;
            // 
            // ultraPanel2
            // 
            appearance3.BackColor = System.Drawing.Color.LightSeaGreen;
            appearance3.BackColor2 = System.Drawing.Color.SteelBlue;
            appearance3.BackGradientAlignment = Infragistics.Win.GradientAlignment.Element;
            appearance3.BackGradientStyle = Infragistics.Win.GradientStyle.ForwardDiagonal;
            appearance3.BackHatchStyle = Infragistics.Win.BackHatchStyle.None;
            appearance3.BorderColor = System.Drawing.Color.Transparent;
            this.ultraPanel2.Appearance = appearance3;
            // 
            // ultraPanel2.ClientArea
            // 
            this.ultraPanel2.ClientArea.Controls.Add(this.btn_publicar);
            this.ultraPanel2.ClientArea.Controls.Add(this.btn_feed_ajuste);
            this.ultraPanel2.ClientArea.Controls.Add(this.btn_Feed_mod);
            this.ultraPanel2.ClientArea.Controls.Add(this.btn_Feed_Chat);
            this.ultraPanel2.ClientArea.Controls.Add(this.btn_Feed_Grupo);
            this.ultraPanel2.ClientArea.Controls.Add(this.btn_Feed_General);
            this.ultraPanel2.ClientArea.Controls.Add(this.ultraPanel3);
            this.ultraPanel2.Location = new System.Drawing.Point(3, 95);
            this.ultraPanel2.Name = "ultraPanel2";
            this.ultraPanel2.Size = new System.Drawing.Size(1019, 38);
            this.ultraPanel2.TabIndex = 0;
            // 
            // btn_publicar
            // 
            this.btn_publicar.BackColor = System.Drawing.Color.Transparent;
            this.btn_publicar.BackgroundImage = global::$safeprojectname$.Properties.Resources.mdi__post_it_note_add;
            this.btn_publicar.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btn_publicar.Cursor = System.Windows.Forms.Cursors.Default;
            this.btn_publicar.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_publicar.ForeColor = System.Drawing.Color.Transparent;
            this.btn_publicar.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btn_publicar.Location = new System.Drawing.Point(215, 4);
            this.btn_publicar.Name = "btn_publicar";
            this.btn_publicar.Size = new System.Drawing.Size(30, 31);
            this.btn_publicar.TabIndex = 6;
            this.btn_publicar.UseVisualStyleBackColor = false;
            this.btn_publicar.Click += new System.EventHandler(this.btn_publicar_Click);
            // 
            // btn_feed_ajuste
            // 
            this.btn_feed_ajuste.BackColor = System.Drawing.Color.Transparent;
            this.btn_feed_ajuste.BackgroundImage = global::$safeprojectname$.Properties.Resources.mdi__settings_stop;
            this.btn_feed_ajuste.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btn_feed_ajuste.Cursor = System.Windows.Forms.Cursors.Default;
            this.btn_feed_ajuste.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_feed_ajuste.ForeColor = System.Drawing.Color.Transparent;
            this.btn_feed_ajuste.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btn_feed_ajuste.Location = new System.Drawing.Point(975, 3);
            this.btn_feed_ajuste.Name = "btn_feed_ajuste";
            this.btn_feed_ajuste.Size = new System.Drawing.Size(30, 31);
            this.btn_feed_ajuste.TabIndex = 5;
            this.btn_feed_ajuste.UseVisualStyleBackColor = false;
            this.btn_feed_ajuste.Click += new System.EventHandler(this.btn_feed_ajuste_Click);
            // 
            // btn_Feed_mod
            // 
            this.btn_Feed_mod.BackColor = System.Drawing.Color.Transparent;
            this.btn_Feed_mod.BackgroundImage = global::$safeprojectname$.Properties.Resources.mdi__mode_edit;
            this.btn_Feed_mod.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btn_Feed_mod.Cursor = System.Windows.Forms.Cursors.Default;
            this.btn_Feed_mod.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_Feed_mod.ForeColor = System.Drawing.Color.Transparent;
            this.btn_Feed_mod.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btn_Feed_mod.Location = new System.Drawing.Point(168, 4);
            this.btn_Feed_mod.Name = "btn_Feed_mod";
            this.btn_Feed_mod.Size = new System.Drawing.Size(30, 31);
            this.btn_Feed_mod.TabIndex = 4;
            this.btn_Feed_mod.UseVisualStyleBackColor = false;
            this.btn_Feed_mod.Click += new System.EventHandler(this.btn_Feed_mod_Click);
            // 
            // btn_Feed_Chat
            // 
            this.btn_Feed_Chat.BackColor = System.Drawing.Color.Transparent;
            this.btn_Feed_Chat.BackgroundImage = global::$safeprojectname$.Properties.Resources.mdi__message_group;
            this.btn_Feed_Chat.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btn_Feed_Chat.Cursor = System.Windows.Forms.Cursors.Default;
            this.btn_Feed_Chat.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_Feed_Chat.ForeColor = System.Drawing.Color.Transparent;
            this.btn_Feed_Chat.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btn_Feed_Chat.Location = new System.Drawing.Point(116, 4);
            this.btn_Feed_Chat.Name = "btn_Feed_Chat";
            this.btn_Feed_Chat.Size = new System.Drawing.Size(30, 31);
            this.btn_Feed_Chat.TabIndex = 3;
            this.btn_Feed_Chat.UseVisualStyleBackColor = false;
            this.btn_Feed_Chat.Click += new System.EventHandler(this.btn_Feed_Chat_Click);
            // 
            // btn_Feed_Grupo
            // 
            this.btn_Feed_Grupo.BackColor = System.Drawing.Color.Transparent;
            this.btn_Feed_Grupo.BackgroundImage = global::$safeprojectname$.Properties.Resources.mdi__account_group;
            this.btn_Feed_Grupo.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btn_Feed_Grupo.Cursor = System.Windows.Forms.Cursors.Default;
            this.btn_Feed_Grupo.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_Feed_Grupo.ForeColor = System.Drawing.Color.Transparent;
            this.btn_Feed_Grupo.Image = global::$safeprojectname$.Properties.Resources.mdi__account_group;
            this.btn_Feed_Grupo.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btn_Feed_Grupo.Location = new System.Drawing.Point(66, 4);
            this.btn_Feed_Grupo.Name = "btn_Feed_Grupo";
            this.btn_Feed_Grupo.Size = new System.Drawing.Size(30, 31);
            this.btn_Feed_Grupo.TabIndex = 2;
            this.btn_Feed_Grupo.UseVisualStyleBackColor = false;
            this.btn_Feed_Grupo.Click += new System.EventHandler(this.btn_Feed_Grupo_Click);
            // 
            // btn_Feed_General
            // 
            this.btn_Feed_General.BackColor = System.Drawing.Color.Transparent;
            this.btn_Feed_General.BackgroundImage = global::$safeprojectname$.Properties.Resources.mdi__post_outline;
            this.btn_Feed_General.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btn_Feed_General.Cursor = System.Windows.Forms.Cursors.Default;
            this.btn_Feed_General.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_Feed_General.ForeColor = System.Drawing.Color.Transparent;
            this.btn_Feed_General.Image = global::$safeprojectname$.Properties.Resources.mdi__post_outline;
            this.btn_Feed_General.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btn_Feed_General.Location = new System.Drawing.Point(19, 4);
            this.btn_Feed_General.Name = "btn_Feed_General";
            this.btn_Feed_General.Size = new System.Drawing.Size(30, 31);
            this.btn_Feed_General.TabIndex = 1;
            this.btn_Feed_General.UseVisualStyleBackColor = false;
            this.btn_Feed_General.Click += new System.EventHandler(this.btn_Feed_General_Click);
            // 
            // ultraPanel3
            // 
            appearance4.BackColor = System.Drawing.Color.Black;
            this.ultraPanel3.Appearance = appearance4;
            this.ultraPanel3.Font = new System.Drawing.Font("Microsoft Sans Serif", 1.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ultraPanel3.Location = new System.Drawing.Point(3, 36);
            this.ultraPanel3.Name = "ultraPanel3";
            this.ultraPanel3.Size = new System.Drawing.Size(1019, 2);
            this.ultraPanel3.TabIndex = 1;
            // 
            // ModificarEvento
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1010, 626);
            this.Controls.Add(this.ultraPanel1);
            this.Name = "ModificarEvento";
            this.Text = "ModificarEvento";
            this.ultraPanel1.ClientArea.ResumeLayout(false);
            this.ultraPanel1.ClientArea.PerformLayout();
            this.ultraPanel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.ultraDateTimeEditor2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ultraDateTimeEditor1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ultraPanel2.ClientArea.ResumeLayout(false);
            this.ultraPanel2.ResumeLayout(false);
            this.ultraPanel3.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private Infragistics.Win.Misc.UltraPanel ultraPanel1;
        private Infragistics.Win.Misc.UltraPanel ultraPanel2;
        private System.Windows.Forms.Button btn_publicar;
        private System.Windows.Forms.Button btn_feed_ajuste;
        private System.Windows.Forms.Button btn_Feed_mod;
        private System.Windows.Forms.Button btn_Feed_Chat;
        private System.Windows.Forms.Button btn_Feed_Grupo;
        private System.Windows.Forms.Button btn_Feed_General;
        private Infragistics.Win.Misc.UltraPanel ultraPanel3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ListBox lb_etiquetas;
        private Infragistics.Win.Misc.UltraLabel ultraLabel1;
        private System.Windows.Forms.TextBox txt_URL;
        private System.Windows.Forms.TextBox txt_texto_post;
        private System.Windows.Forms.Button btn_cargar_img;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private Infragistics.Win.UltraWinEditors.UltraDateTimeEditor ultraDateTimeEditor2;
        private Infragistics.Win.UltraWinEditors.UltraDateTimeEditor ultraDateTimeEditor1;
        private System.Windows.Forms.Button button1;
    }
}