﻿
namespace $safeprojectname$.Feeds.Feed_Modificar.Modificar_opciones
{
    partial class ModificarPerfil
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Infragistics.Win.Appearance appearance1 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance2 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance3 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance4 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance5 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance6 = new Infragistics.Win.Appearance();
            this.ultraPanel1 = new Infragistics.Win.Misc.UltraPanel();
            this.ultraLabel3 = new Infragistics.Win.Misc.UltraLabel();
            this.btn_modificar = new System.Windows.Forms.Button();
            this.txt_nomber = new System.Windows.Forms.TextBox();
            this.ultraLabel2 = new Infragistics.Win.Misc.UltraLabel();
            this.ultraLabel1 = new Infragistics.Win.Misc.UltraLabel();
            this.ultraDateTimeEditor1 = new Infragistics.Win.UltraWinEditors.UltraDateTimeEditor();
            this.txt_descripcion = new System.Windows.Forms.TextBox();
            this.btn_cargar_img = new System.Windows.Forms.Button();
            this.pib_img = new System.Windows.Forms.PictureBox();
            this.ultraPanel2 = new Infragistics.Win.Misc.UltraPanel();
            this.btn_publicar = new System.Windows.Forms.Button();
            this.btn_feed_ajuste = new System.Windows.Forms.Button();
            this.btn_Feed_mod = new System.Windows.Forms.Button();
            this.btn_Feed_Chat = new System.Windows.Forms.Button();
            this.btn_Feed_Grupo = new System.Windows.Forms.Button();
            this.btn_Feed_General = new System.Windows.Forms.Button();
            this.ultraPanel3 = new Infragistics.Win.Misc.UltraPanel();
            this.ultraPanel1.ClientArea.SuspendLayout();
            this.ultraPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ultraDateTimeEditor1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pib_img)).BeginInit();
            this.ultraPanel2.ClientArea.SuspendLayout();
            this.ultraPanel2.SuspendLayout();
            this.ultraPanel3.SuspendLayout();
            this.SuspendLayout();
            // 
            // ultraPanel1
            // 
            appearance1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            appearance1.BackColor2 = System.Drawing.Color.Navy;
            appearance1.BackColorDisabled = System.Drawing.Color.White;
            appearance1.BackGradientAlignment = Infragistics.Win.GradientAlignment.Form;
            appearance1.BackGradientStyle = Infragistics.Win.GradientStyle.BackwardDiagonal;
            this.ultraPanel1.Appearance = appearance1;
            this.ultraPanel1.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            // 
            // ultraPanel1.ClientArea
            // 
            this.ultraPanel1.ClientArea.Controls.Add(this.ultraLabel3);
            this.ultraPanel1.ClientArea.Controls.Add(this.btn_modificar);
            this.ultraPanel1.ClientArea.Controls.Add(this.txt_nomber);
            this.ultraPanel1.ClientArea.Controls.Add(this.ultraLabel2);
            this.ultraPanel1.ClientArea.Controls.Add(this.ultraLabel1);
            this.ultraPanel1.ClientArea.Controls.Add(this.ultraDateTimeEditor1);
            this.ultraPanel1.ClientArea.Controls.Add(this.txt_descripcion);
            this.ultraPanel1.ClientArea.Controls.Add(this.btn_cargar_img);
            this.ultraPanel1.ClientArea.Controls.Add(this.pib_img);
            this.ultraPanel1.ClientArea.Controls.Add(this.ultraPanel2);
            this.ultraPanel1.Location = new System.Drawing.Point(-9, -95);
            this.ultraPanel1.Name = "ultraPanel1";
            this.ultraPanel1.Size = new System.Drawing.Size(1032, 817);
            this.ultraPanel1.TabIndex = 2;
            // 
            // ultraLabel3
            // 
            appearance2.BackColor = System.Drawing.Color.Transparent;
            this.ultraLabel3.Appearance = appearance2;
            this.ultraLabel3.AutoSize = true;
            this.ultraLabel3.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ultraLabel3.Location = new System.Drawing.Point(389, 204);
            this.ultraLabel3.Name = "ultraLabel3";
            this.ultraLabel3.Size = new System.Drawing.Size(158, 27);
            this.ultraLabel3.TabIndex = 13;
            this.ultraLabel3.Text = "DESCRIPCION";
            // 
            // btn_modificar
            // 
            this.btn_modificar.BackColor = System.Drawing.Color.Transparent;
            this.btn_modificar.BackgroundImage = global::$safeprojectname$.Properties.Resources.mdi__arrow_up_bold;
            this.btn_modificar.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btn_modificar.Cursor = System.Windows.Forms.Cursors.Default;
            this.btn_modificar.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_modificar.ForeColor = System.Drawing.Color.Transparent;
            this.btn_modificar.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btn_modificar.Location = new System.Drawing.Point(152, 608);
            this.btn_modificar.Name = "btn_modificar";
            this.btn_modificar.Size = new System.Drawing.Size(679, 101);
            this.btn_modificar.TabIndex = 7;
            this.btn_modificar.UseVisualStyleBackColor = false;
            // 
            // txt_nomber
            // 
            this.txt_nomber.Location = new System.Drawing.Point(727, 367);
            this.txt_nomber.Name = "txt_nomber";
            this.txt_nomber.Size = new System.Drawing.Size(226, 20);
            this.txt_nomber.TabIndex = 12;
            // 
            // ultraLabel2
            // 
            appearance3.BackColor = System.Drawing.Color.Transparent;
            this.ultraLabel2.Appearance = appearance3;
            this.ultraLabel2.AutoSize = true;
            this.ultraLabel2.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ultraLabel2.Location = new System.Drawing.Point(789, 334);
            this.ultraLabel2.Name = "ultraLabel2";
            this.ultraLabel2.Size = new System.Drawing.Size(102, 27);
            this.ultraLabel2.TabIndex = 11;
            this.ultraLabel2.Text = "NOMBRE";
            // 
            // ultraLabel1
            // 
            appearance4.BackColor = System.Drawing.Color.Transparent;
            this.ultraLabel1.Appearance = appearance4;
            this.ultraLabel1.AutoSize = true;
            this.ultraLabel1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ultraLabel1.Location = new System.Drawing.Point(715, 240);
            this.ultraLabel1.Name = "ultraLabel1";
            this.ultraLabel1.Size = new System.Drawing.Size(252, 27);
            this.ultraLabel1.TabIndex = 10;
            this.ultraLabel1.Text = "FECHA DE NACIMENTO";
            // 
            // ultraDateTimeEditor1
            // 
            this.ultraDateTimeEditor1.DisplayStyle = Infragistics.Win.EmbeddableElementDisplayStyle.Office2013;
            this.ultraDateTimeEditor1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ultraDateTimeEditor1.Location = new System.Drawing.Point(727, 273);
            this.ultraDateTimeEditor1.MaskInput = "{LOC}mm/dd/yyyy hh:mm:ss tt";
            this.ultraDateTimeEditor1.Name = "ultraDateTimeEditor1";
            this.ultraDateTimeEditor1.Size = new System.Drawing.Size(226, 28);
            this.ultraDateTimeEditor1.TabIndex = 9;
            // 
            // txt_descripcion
            // 
            this.txt_descripcion.Location = new System.Drawing.Point(302, 237);
            this.txt_descripcion.Multiline = true;
            this.txt_descripcion.Name = "txt_descripcion";
            this.txt_descripcion.Size = new System.Drawing.Size(340, 200);
            this.txt_descripcion.TabIndex = 8;
            // 
            // btn_cargar_img
            // 
            this.btn_cargar_img.BackColor = System.Drawing.Color.Transparent;
            this.btn_cargar_img.BackgroundImage = global::$safeprojectname$.Properties.Resources.mdi__post_it_note_add;
            this.btn_cargar_img.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btn_cargar_img.Cursor = System.Windows.Forms.Cursors.Default;
            this.btn_cargar_img.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_cargar_img.ForeColor = System.Drawing.Color.Transparent;
            this.btn_cargar_img.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btn_cargar_img.Location = new System.Drawing.Point(51, 443);
            this.btn_cargar_img.Name = "btn_cargar_img";
            this.btn_cargar_img.Size = new System.Drawing.Size(212, 31);
            this.btn_cargar_img.TabIndex = 7;
            this.btn_cargar_img.UseVisualStyleBackColor = false;
            // 
            // pib_img
            // 
            this.pib_img.Location = new System.Drawing.Point(51, 237);
            this.pib_img.Name = "pib_img";
            this.pib_img.Size = new System.Drawing.Size(212, 200);
            this.pib_img.TabIndex = 1;
            this.pib_img.TabStop = false;
            // 
            // ultraPanel2
            // 
            appearance5.BackColor = System.Drawing.Color.LightSeaGreen;
            appearance5.BackColor2 = System.Drawing.Color.SteelBlue;
            appearance5.BackGradientAlignment = Infragistics.Win.GradientAlignment.Element;
            appearance5.BackGradientStyle = Infragistics.Win.GradientStyle.ForwardDiagonal;
            appearance5.BackHatchStyle = Infragistics.Win.BackHatchStyle.None;
            appearance5.BorderColor = System.Drawing.Color.Transparent;
            this.ultraPanel2.Appearance = appearance5;
            // 
            // ultraPanel2.ClientArea
            // 
            this.ultraPanel2.ClientArea.Controls.Add(this.btn_publicar);
            this.ultraPanel2.ClientArea.Controls.Add(this.btn_feed_ajuste);
            this.ultraPanel2.ClientArea.Controls.Add(this.btn_Feed_mod);
            this.ultraPanel2.ClientArea.Controls.Add(this.btn_Feed_Chat);
            this.ultraPanel2.ClientArea.Controls.Add(this.btn_Feed_Grupo);
            this.ultraPanel2.ClientArea.Controls.Add(this.btn_Feed_General);
            this.ultraPanel2.ClientArea.Controls.Add(this.ultraPanel3);
            this.ultraPanel2.Location = new System.Drawing.Point(3, 95);
            this.ultraPanel2.Name = "ultraPanel2";
            this.ultraPanel2.Size = new System.Drawing.Size(1019, 38);
            this.ultraPanel2.TabIndex = 0;
            // 
            // btn_publicar
            // 
            this.btn_publicar.BackColor = System.Drawing.Color.Transparent;
            this.btn_publicar.BackgroundImage = global::$safeprojectname$.Properties.Resources.mdi__post_it_note_add;
            this.btn_publicar.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btn_publicar.Cursor = System.Windows.Forms.Cursors.Default;
            this.btn_publicar.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_publicar.ForeColor = System.Drawing.Color.Transparent;
            this.btn_publicar.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btn_publicar.Location = new System.Drawing.Point(215, 4);
            this.btn_publicar.Name = "btn_publicar";
            this.btn_publicar.Size = new System.Drawing.Size(30, 31);
            this.btn_publicar.TabIndex = 6;
            this.btn_publicar.UseVisualStyleBackColor = false;
            this.btn_publicar.Click += new System.EventHandler(this.btn_publicar_Click);
            // 
            // btn_feed_ajuste
            // 
            this.btn_feed_ajuste.BackColor = System.Drawing.Color.Transparent;
            this.btn_feed_ajuste.BackgroundImage = global::$safeprojectname$.Properties.Resources.mdi__settings_stop;
            this.btn_feed_ajuste.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btn_feed_ajuste.Cursor = System.Windows.Forms.Cursors.Default;
            this.btn_feed_ajuste.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_feed_ajuste.ForeColor = System.Drawing.Color.Transparent;
            this.btn_feed_ajuste.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btn_feed_ajuste.Location = new System.Drawing.Point(975, 3);
            this.btn_feed_ajuste.Name = "btn_feed_ajuste";
            this.btn_feed_ajuste.Size = new System.Drawing.Size(30, 31);
            this.btn_feed_ajuste.TabIndex = 5;
            this.btn_feed_ajuste.UseVisualStyleBackColor = false;
            this.btn_feed_ajuste.Click += new System.EventHandler(this.btn_feed_ajuste_Click);
            // 
            // btn_Feed_mod
            // 
            this.btn_Feed_mod.BackColor = System.Drawing.Color.Transparent;
            this.btn_Feed_mod.BackgroundImage = global::$safeprojectname$.Properties.Resources.mdi__mode_edit;
            this.btn_Feed_mod.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btn_Feed_mod.Cursor = System.Windows.Forms.Cursors.Default;
            this.btn_Feed_mod.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_Feed_mod.ForeColor = System.Drawing.Color.Transparent;
            this.btn_Feed_mod.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btn_Feed_mod.Location = new System.Drawing.Point(168, 4);
            this.btn_Feed_mod.Name = "btn_Feed_mod";
            this.btn_Feed_mod.Size = new System.Drawing.Size(30, 31);
            this.btn_Feed_mod.TabIndex = 4;
            this.btn_Feed_mod.UseVisualStyleBackColor = false;
            this.btn_Feed_mod.Click += new System.EventHandler(this.btn_Feed_mod_Click);
            // 
            // btn_Feed_Chat
            // 
            this.btn_Feed_Chat.BackColor = System.Drawing.Color.Transparent;
            this.btn_Feed_Chat.BackgroundImage = global::$safeprojectname$.Properties.Resources.mdi__message_group;
            this.btn_Feed_Chat.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btn_Feed_Chat.Cursor = System.Windows.Forms.Cursors.Default;
            this.btn_Feed_Chat.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_Feed_Chat.ForeColor = System.Drawing.Color.Transparent;
            this.btn_Feed_Chat.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btn_Feed_Chat.Location = new System.Drawing.Point(116, 4);
            this.btn_Feed_Chat.Name = "btn_Feed_Chat";
            this.btn_Feed_Chat.Size = new System.Drawing.Size(30, 31);
            this.btn_Feed_Chat.TabIndex = 3;
            this.btn_Feed_Chat.UseVisualStyleBackColor = false;
            this.btn_Feed_Chat.Click += new System.EventHandler(this.btn_Feed_Chat_Click);
            // 
            // btn_Feed_Grupo
            // 
            this.btn_Feed_Grupo.BackColor = System.Drawing.Color.Transparent;
            this.btn_Feed_Grupo.BackgroundImage = global::$safeprojectname$.Properties.Resources.mdi__account_group;
            this.btn_Feed_Grupo.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btn_Feed_Grupo.Cursor = System.Windows.Forms.Cursors.Default;
            this.btn_Feed_Grupo.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_Feed_Grupo.ForeColor = System.Drawing.Color.Transparent;
            this.btn_Feed_Grupo.Image = global::$safeprojectname$.Properties.Resources.mdi__account_group;
            this.btn_Feed_Grupo.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btn_Feed_Grupo.Location = new System.Drawing.Point(66, 4);
            this.btn_Feed_Grupo.Name = "btn_Feed_Grupo";
            this.btn_Feed_Grupo.Size = new System.Drawing.Size(30, 31);
            this.btn_Feed_Grupo.TabIndex = 2;
            this.btn_Feed_Grupo.UseVisualStyleBackColor = false;
            this.btn_Feed_Grupo.Click += new System.EventHandler(this.btn_Feed_Grupo_Click);
            // 
            // btn_Feed_General
            // 
            this.btn_Feed_General.BackColor = System.Drawing.Color.Transparent;
            this.btn_Feed_General.BackgroundImage = global::$safeprojectname$.Properties.Resources.mdi__post_outline;
            this.btn_Feed_General.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btn_Feed_General.Cursor = System.Windows.Forms.Cursors.Default;
            this.btn_Feed_General.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_Feed_General.ForeColor = System.Drawing.Color.Transparent;
            this.btn_Feed_General.Image = global::$safeprojectname$.Properties.Resources.mdi__post_outline;
            this.btn_Feed_General.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btn_Feed_General.Location = new System.Drawing.Point(19, 4);
            this.btn_Feed_General.Name = "btn_Feed_General";
            this.btn_Feed_General.Size = new System.Drawing.Size(30, 31);
            this.btn_Feed_General.TabIndex = 1;
            this.btn_Feed_General.UseVisualStyleBackColor = false;
            this.btn_Feed_General.Click += new System.EventHandler(this.btn_Feed_General_Click);
            // 
            // ultraPanel3
            // 
            appearance6.BackColor = System.Drawing.Color.Black;
            this.ultraPanel3.Appearance = appearance6;
            this.ultraPanel3.Font = new System.Drawing.Font("Microsoft Sans Serif", 1.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ultraPanel3.Location = new System.Drawing.Point(3, 36);
            this.ultraPanel3.Name = "ultraPanel3";
            this.ultraPanel3.Size = new System.Drawing.Size(1019, 2);
            this.ultraPanel3.TabIndex = 1;
            // 
            // ModificarPerfil
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1010, 626);
            this.Controls.Add(this.ultraPanel1);
            this.Name = "ModificarPerfil";
            this.Text = "ModificarPerfil";
            this.ultraPanel1.ClientArea.ResumeLayout(false);
            this.ultraPanel1.ClientArea.PerformLayout();
            this.ultraPanel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.ultraDateTimeEditor1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pib_img)).EndInit();
            this.ultraPanel2.ClientArea.ResumeLayout(false);
            this.ultraPanel2.ResumeLayout(false);
            this.ultraPanel3.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private Infragistics.Win.Misc.UltraPanel ultraPanel1;
        private Infragistics.Win.Misc.UltraPanel ultraPanel2;
        private System.Windows.Forms.Button btn_publicar;
        private System.Windows.Forms.Button btn_feed_ajuste;
        private System.Windows.Forms.Button btn_Feed_mod;
        private System.Windows.Forms.Button btn_Feed_Chat;
        private System.Windows.Forms.Button btn_Feed_Grupo;
        private System.Windows.Forms.Button btn_Feed_General;
        private Infragistics.Win.Misc.UltraPanel ultraPanel3;
        private Infragistics.Win.Misc.UltraLabel ultraLabel3;
        private System.Windows.Forms.Button btn_modificar;
        private System.Windows.Forms.TextBox txt_nomber;
        private Infragistics.Win.Misc.UltraLabel ultraLabel2;
        private Infragistics.Win.Misc.UltraLabel ultraLabel1;
        private Infragistics.Win.UltraWinEditors.UltraDateTimeEditor ultraDateTimeEditor1;
        private System.Windows.Forms.TextBox txt_descripcion;
        private System.Windows.Forms.Button btn_cargar_img;
        private System.Windows.Forms.PictureBox pib_img;
    }
}