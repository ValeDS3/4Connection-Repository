﻿using $safeprojectname$.Logica;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace $safeprojectname$.Feeds.Feed_General
{
    public partial class FeedGeneral : Form
    {
        Feed_Ajustes.FeedAjustes FeedAjustes;
        Feed_Chat.FeedChat FeedChat;
        Feed_Grupo.FeedGrupos FeedGrupos;
        Feed_Modificar.Feed_Modificar Feed_Modificar;
        Feed_Publicar.Feed_publicar Feed_Publicar;
        private readonly Postservice postService = new Postservice();
        private List<Post> posts = new List<Post>();
        private int currentPostIndex = 0;


        public FeedGeneral()
        {
            InitializeComponent();
            /*listView1.Items.Add("hola so jose y como soy jose puedo comentyaro lo querio de cualquier cosa si es lo que ves essdfjkdjflkdsjaf ");*/
            Load += async (s, e) => await CargarPostsAsync();
            button2.Click += (s, e) => MostrarPostAnterior();
            button1.Click += (s, e) => MostrarPostSiguiente();
        }


        private async Task CargarPostsAsync()
        {
            try
             {
                posts = await postService.ObtenerPostsAsync() ?? new List<Post>();

                if (posts.Count == 0)
                {
                    MessageBox.Show("No se encontraron posts.");
                    return;
                }

                // Cargar imágenes de cada post
                foreach (var post in posts)
                {
                    // Obtiene la primera imagen del post, si existe
                    var imagenes = await postService.ObtenerImagenesDePostAsync(post.IdPost.Value);
                    if (imagenes.Count > 0)
                    {
                        post.Imagenes = imagenes; // Asigna las imágenes al post
                    }
                }

                // Muestra el primer post en la lista
                MostrarPost(currentPostIndex);
            }
    catch (Exception ex)
            {
                MessageBox.Show($"Error al cargar los posts: {ex.Message}");
            }
        }

        private void MostrarPost(int index)
        {
            if (index >= 0 && index < posts.Count)
            {
                var post = posts[index];
                label1.Text = post.Texto;

                // Obtener la primera imagen del post si existe
                byte[] primeraImagen = post.Imagenes.FirstOrDefault();

                if (primeraImagen != null)
                {
                    using (var ms = new System.IO.MemoryStream(primeraImagen))
                    {
                        pictureBox1.Image = Image.FromStream(ms);
                    }
                }
                else
                {
                    pictureBox1.Image = null; // Limpiar el PictureBox si no hay imagen
                }
            }

        }

        private void MostrarPostAnterior()
        {
            if (currentPostIndex > 0)
            {
                currentPostIndex--;
                MostrarPost(currentPostIndex);
            }
        }

        private void MostrarPostSiguiente()
        {
            if (currentPostIndex < posts.Count - 1)
            {
                currentPostIndex++;
                MostrarPost(currentPostIndex);
            }
        }
        private void btn_Feed_General_Click(object sender, EventArgs e)
        {

        }

        private void btn_Feed_Grupo_Click(object sender, EventArgs e)
        {
            this.Close();
            if (FeedGrupos == null || FeedGrupos.IsDisposed)
            {
                FeedGrupos = new Feed_Grupo.FeedGrupos();
                FeedGrupos.Show();
            }
            else
            {
                FeedGrupos.Show();
            }
        }

        private void btn_Feed_Chat_Click(object sender, EventArgs e)
        {
            this.Close();
            if (FeedChat == null || FeedChat.IsDisposed)
            {
                FeedChat = new Feed_Chat.FeedChat();
                FeedChat.Show();
            }
            else
            {
                FeedChat.Show();
            }
        }

        private void btn_Feed_mod_Click(object sender, EventArgs e)
        {
            this.Close();
            if (Feed_Modificar == null || Feed_Modificar.IsDisposed)
            {
                Feed_Modificar = new Feed_Modificar.Feed_Modificar();
                Feed_Modificar.Show();
            }
            else
            {
                Feed_Modificar.Show();
            }
        }

        private void btn_publicar_Click(object sender, EventArgs e)
        {
            this.Close();
            if (Feed_Publicar == null || Feed_Publicar.IsDisposed)
            {
                Feed_Publicar = new Feeds.Feed_Publicar.Feed_publicar();
                Feed_Publicar.Show();
            }
            else
            {
                Feed_Publicar.Show();
            }
        }

        private void btn_feed_ajuste_Click(object sender, EventArgs e)
        {
            this.Close();
            if (FeedAjustes == null || FeedAjustes.IsDisposed)
            {
                FeedAjustes = new Feed_Ajustes.FeedAjustes();
                FeedAjustes.Show();
            }
            else
            {
                FeedAjustes.Show();
            }
        }

        private async void ultraPanel1_PaintClient(object sender, PaintEventArgs e)
        {

        }

        private void FeedGeneral_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
                    }
    }
}
