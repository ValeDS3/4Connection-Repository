﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace $safeprojectname$
{
    public partial class PostControlador : UserControl
    {
        public PostControlador()
        {
            InitializeComponent();
        }

        private void PostControlador_Load(object sender, EventArgs e)
        {

        }

        public void SetPostData(string contenido, byte[] imagen)
        {
            txtContenido.Text = contenido;

            if (imagen !=null && imagen.Length>0)
            {
                using (var ms = new MemoryStream(imagen))
                {
                    pictureBox1.Image = Image.FromStream(ms);
                }
               
            }
            else
            {
                pictureBox1.Visible = false; // Oculta la imagen si no hay URL
            }
        }

        

        
    }
    }
