﻿
namespace $safeprojectname$
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            Infragistics.Win.Appearance appearance1 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance2 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance3 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance4 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance5 = new Infragistics.Win.Appearance();
            this.ultraPanel1 = new Infragistics.Win.Misc.UltraPanel();
            this.brn_loging = new Infragistics.Win.Misc.UltraButton();
            this.ultraTextEditor1 = new Infragistics.Win.UltraWinEditors.UltraTextEditor();
            this.ultraTextEditor3 = new Infragistics.Win.UltraWinEditors.UltraTextEditor();
            this.ultraPictureBox1 = new Infragistics.Win.UltraWinEditors.UltraPictureBox();
            this.ultraPanel1.ClientArea.SuspendLayout();
            this.ultraPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ultraTextEditor1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ultraTextEditor3)).BeginInit();
            this.SuspendLayout();
            // 
            // ultraPanel1
            // 
            appearance1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            appearance1.BackColor2 = System.Drawing.Color.Navy;
            appearance1.BackColorDisabled = System.Drawing.Color.White;
            appearance1.BackGradientAlignment = Infragistics.Win.GradientAlignment.Form;
            appearance1.BackGradientStyle = Infragistics.Win.GradientStyle.BackwardDiagonal;
            this.ultraPanel1.Appearance = appearance1;
            // 
            // ultraPanel1.ClientArea
            // 
            this.ultraPanel1.ClientArea.Controls.Add(this.brn_loging);
            this.ultraPanel1.ClientArea.Controls.Add(this.ultraTextEditor1);
            this.ultraPanel1.ClientArea.Controls.Add(this.ultraTextEditor3);
            this.ultraPanel1.ClientArea.Controls.Add(this.ultraPictureBox1);
            this.ultraPanel1.Location = new System.Drawing.Point(-2, -1);
            this.ultraPanel1.Name = "ultraPanel1";
            this.ultraPanel1.Size = new System.Drawing.Size(696, 722);
            this.ultraPanel1.TabIndex = 0;
            this.ultraPanel1.PaintClient += new System.Windows.Forms.PaintEventHandler(this.ultraPanel1_PaintClient);
            this.ultraPanel1.Paint += new System.Windows.Forms.PaintEventHandler(this.ultraPanel1_Paint);
            // 
            // brn_loging
            // 
            appearance2.BackColor = System.Drawing.Color.Transparent;
            appearance2.BorderColor = System.Drawing.Color.Transparent;
            appearance2.BorderColor3DBase = System.Drawing.Color.Transparent;
            appearance2.FontData.Name = "Segoe UI";
            this.brn_loging.Appearance = appearance2;
            this.brn_loging.ButtonStyle = Infragistics.Win.UIElementButtonStyle.Button;
            this.brn_loging.Font = new System.Drawing.Font("Segoe UI", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.brn_loging.Location = new System.Drawing.Point(165, 379);
            this.brn_loging.Name = "brn_loging";
            this.brn_loging.Size = new System.Drawing.Size(289, 60);
            this.brn_loging.TabIndex = 6;
            this.brn_loging.Text = "LOGING";
            this.brn_loging.Click += new System.EventHandler(this.brn_loging_Click);
            // 
            // ultraTextEditor1
            // 
            this.ultraTextEditor1.BorderStyle = Infragistics.Win.UIElementBorderStyle.None;
            this.ultraTextEditor1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ultraTextEditor1.Location = new System.Drawing.Point(165, 309);
            this.ultraTextEditor1.Name = "ultraTextEditor1";
            this.ultraTextEditor1.NullText = "Contraseña";
            appearance3.ForeColor = System.Drawing.Color.Silver;
            this.ultraTextEditor1.NullTextAppearance = appearance3;
            this.ultraTextEditor1.Size = new System.Drawing.Size(289, 24);
            this.ultraTextEditor1.TabIndex = 4;
            // 
            // ultraTextEditor3
            // 
            this.ultraTextEditor3.BorderStyle = Infragistics.Win.UIElementBorderStyle.None;
            this.ultraTextEditor3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ultraTextEditor3.Location = new System.Drawing.Point(165, 229);
            this.ultraTextEditor3.Name = "ultraTextEditor3";
            this.ultraTextEditor3.NullText = "Usuario";
            appearance4.BackColor = System.Drawing.Color.White;
            appearance4.BackColor2 = System.Drawing.Color.White;
            appearance4.ForeColor = System.Drawing.Color.DarkGray;
            this.ultraTextEditor3.NullTextAppearance = appearance4;
            this.ultraTextEditor3.Size = new System.Drawing.Size(289, 24);
            this.ultraTextEditor3.TabIndex = 3;
            // 
            // ultraPictureBox1
            // 
            appearance5.BackColor = System.Drawing.Color.Transparent;
            this.ultraPictureBox1.Appearance = appearance5;
            this.ultraPictureBox1.BackColor = System.Drawing.Color.Transparent;
            this.ultraPictureBox1.BackColorInternal = System.Drawing.Color.Transparent;
            this.ultraPictureBox1.BorderShadowColor = System.Drawing.Color.Empty;
            this.ultraPictureBox1.DefaultImage = global::$safeprojectname$.Properties.Resources.mdi__account_circle_outline;
            this.ultraPictureBox1.Location = new System.Drawing.Point(205, 13);
            this.ultraPictureBox1.Name = "ultraPictureBox1";
            this.ultraPictureBox1.Size = new System.Drawing.Size(203, 201);
            this.ultraPictureBox1.TabIndex = 2;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(96F, 96F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
            this.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.ClientSize = new System.Drawing.Size(612, 605);
            this.Controls.Add(this.ultraPanel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.SizableToolWindow;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "LOGING";
            this.ultraPanel1.ClientArea.ResumeLayout(false);
            this.ultraPanel1.ClientArea.PerformLayout();
            this.ultraPanel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.ultraTextEditor1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ultraTextEditor3)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private Infragistics.Win.Misc.UltraPanel ultraPanel1;
        private Infragistics.Win.UltraWinEditors.UltraPictureBox ultraPictureBox1;
        private Infragistics.Win.UltraWinEditors.UltraTextEditor ultraTextEditor3;
        private Infragistics.Win.UltraWinEditors.UltraTextEditor ultraTextEditor1;
        private Infragistics.Win.Misc.UltraButton brn_loging;
    }
}

