﻿using RestSharp;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xunit;

namespace $safeprojectname$.Test
{
    public class ApiPostTest
    {
        private readonly string apiBaseUrl = "https://localhost:44381/swagger/index.html";

        [Fact]
        public void GetResource_ShouldReturnStatus200()
        {
            var client = new RestClient(apiBaseUrl);
            var request = new RestRequest("/api/PostControlador", Method.Get);

            var response = client.Execute(request);

            Assert.Equal(200, (int)response.StatusCode);
        }

        [Fact]
        public void PostResource_ShouldReturnStatus201()
        {
            var client = new RestClient("https://localhost:44381");
            var request = new RestRequest("/api/GrupoControlador", Method.Post);

            request.AddJsonBody(new
            {
                idUsuario= 1,
                urlVideo= "Testapi",
                texto="Testapi"
            });

            request.AddHeader("Content-Type", "application/json");

            var response = client.Execute(request);


            Assert.Equal(201, (int)response.StatusCode);
        }
        [Fact]
        public void PutResource_ShouldReturnStatus200()
        {
            var client = new RestClient("https://localhost:44381");
            var request = new RestRequest("/api/PostControlador", Method.Put);

            request.AddJsonBody(new
            {
                idPost = 2,
                idusuario= 1,
                urlVideo = "TestPut",
                texto= "testPut"
               
            });

            request.AddHeader("Content-Type", "application/json");

            var response = client.Execute(request);

            Assert.Equal(204, (int)response.StatusCode);
        }

        [Fact]
        public void DeleteResource_ShouldReturnStatus204()
        {
            var client = new RestClient("https://localhost:44381");
            var request = new RestRequest("/api/PostControlador/2", Method.Delete);

            var response = client.Execute(request);

            Assert.Equal(204, (int)response.StatusCode);
        }

        [Fact]
        public void GetResource_ShouldContainSpecificData()
        {
            var client = new RestClient("https://localhost:44381");
            var request = new RestRequest("/api/PostControlador/6", Method.Get);

            var response = client.Execute(request);

            Assert.Equal(200, (int)response.StatusCode);

            var jsonResponse = Newtonsoft.Json.JsonConvert.DeserializeObject<dynamic>(response.Content);

            Assert.Equal(6, (int)jsonResponse.idPost);
            Assert.Equal(2, (int)jsonResponse.idUsuario);
            Assert.Equal("uhsuihksjdldsd", (string)jsonResponse.urlVideo);
            Assert.Equal("strikdjlkdjdang", (string)jsonResponse.texto);
            Assert.Equal("09/20/2024 16:46:21", (string)jsonResponse.fecha);
        }

    }
}

