﻿using RestSharp;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xunit;

namespace $safeprojectname$.Test
{
    public class ApiUsuariotest
    {
        private readonly string apiBaseUrl = "https://localhost:44350/swagger/index.html";

        [Fact]
        public void GetResource_ShouldReturnStatus200()
        {
            var client = new RestClient(apiBaseUrl);
            var request = new RestRequest("/api/UsuarioControlador", Method.Get);

            var response = client.Execute(request);

            Assert.Equal(200, (int)response.StatusCode);
        }

        [Fact]
        public void PostResource_ShouldReturnStatus201()
        {
            var client = new RestClient("https://localhost:44350");
            var request = new RestRequest("/api/GrupoControlador", Method.Post);

            request.AddJsonBody(new
            {
               
                nombre= "TestAPi",
                fechaNac= "2014/05/05",
                descripcion="testApi"
            });

            request.AddHeader("Content-Type", "application/json");

            var response = client.Execute(request);


            Assert.Equal(201, (int)response.StatusCode);
        }
        [Fact]
        public void PutResource_ShouldReturnStatus200()
        {
            var client = new RestClient("https://localhost:44350");
            var request = new RestRequest("/api/UsuarioControlador", Method.Put);

            request.AddJsonBody(new
            {
                idusuario = 1,
                nombre = "juan",
                fechanac = "2014/05/05",
                descricpcion = "testPut"

            });

            request.AddHeader("Content-Type", "application/json");

            var response = client.Execute(request);

            Assert.Equal(204, (int)response.StatusCode);
        }

        [Fact]
        public void DeleteResource_ShouldReturnStatus204()
        {
            var client = new RestClient("https://localhost:44350");
            var request = new RestRequest("/api/UsuarioControlador/2", Method.Delete);

            var response = client.Execute(request);

            Assert.Equal(204, (int)response.StatusCode);
        }

        [Fact]
        public void GetResource_ShouldContainSpecificData()
        {
            var client = new RestClient("https://localhost:44350");
            var request = new RestRequest("/api/usuarioControlador/1", Method.Get);

            var response = client.Execute(request);

            Assert.Equal(200, (int)response.StatusCode);

            var jsonResponse = Newtonsoft.Json.JsonConvert.DeserializeObject<dynamic>(response.Content);

            Assert.Equal(2, (int)jsonResponse.idUsuario);
            Assert.Equal("prueba", (string)jsonResponse.nombre);
            Assert.Equal("05/07/2014 00:00:00", (string)jsonResponse.fechaNac);
            Assert.Equal("stringlkcmdcojdsci", (string)jsonResponse.descripcion);
        }
    }
}
