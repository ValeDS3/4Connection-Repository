﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using RestSharp;
using Xunit;


namespace $safeprojectname$.Test
{
    public class ApiGrupoTest
    {
        private readonly string apiBaseUrl= "hhttps://localhost:44350/swagger/index.html";

        [Fact]
        public void GetResource_ShouldReturnStatus200()
        {
            var client = new RestClient(apiBaseUrl);
            var request = new RestRequest("/api/GrupoControlador", Method.Get);

            var response = client.Execute(request);

            Assert.Equal(200, (int)response.StatusCode);
        }

        [Fact]
        public void PostResource_ShouldReturnStatus201()
        {
            var client = new RestClient("https://localhost:44350");  
            var request = new RestRequest("/api/GrupoControlador", Method.Post);  

            request.AddJsonBody(new
            {
                nombreGrupo = "GrupoTest",  
                usuarioCreador = 1,
                descripcion = "GrupoTest",
                codigoInvitacion = "Grupotest"
            });

            request.AddHeader("Content-Type", "application/json");  

            var response = client.Execute(request);

            
            Assert.Equal(201, (int)response.StatusCode);
        }
        [Fact]
        public void PutResource_ShouldReturnStatus200()
        {
            var client = new RestClient("https://localhost:44350");  
            var request = new RestRequest("/api/GrupoControlador", Method.Put);  

            request.AddJsonBody(new
            {
                codigoGrupo = 4,  
                nombreGrupo = "cambiotest",
                usuarioCreador = 1,
                descripcion = "cambiotest",
                codigoInvitacion = "cambiotest"
            });

            request.AddHeader("Content-Type", "application/json");

            var response = client.Execute(request);

            Assert.Equal(204, (int)response.StatusCode);
        }

        [Fact]
        public void DeleteResource_ShouldReturnStatus204()
        {
            var client = new RestClient("https://localhost:44350"); 
            var request = new RestRequest("/api/GrupoControlador/5", Method.Delete);  

            var response = client.Execute(request);

            Assert.Equal(204, (int)response.StatusCode);
        }

        [Fact]
        public void GetResource_ShouldContainSpecificData()
        {
            var client = new RestClient("https://localhost:44350");  
            var request = new RestRequest("/api/GrupoControlador/4", Method.Get);  

            var response = client.Execute(request);

            Assert.Equal(200, (int)response.StatusCode);

            var jsonResponse = Newtonsoft.Json.JsonConvert.DeserializeObject<dynamic>(response.Content);

            Assert.Equal(4, (int)jsonResponse.codigoGrupo);  // Validar que el código del grupo sea 4
            Assert.Equal("nombreGrupoEsperado", (string)jsonResponse.nombreGrupo);  // Cambiar al nombre real esperado
            Assert.Equal(1, (int)jsonResponse.usuarioCreador);  // Validar el usuario creador
            Assert.Equal("descripcionEsperada", (string)jsonResponse.descripcion);  // Cambiar a la descripción real esperada
            Assert.Equal("codigoInvitacionEsperado", (string)jsonResponse.codigoInvitacion);  // Cambiar al código de invitación real esperado
        }

    }
}
