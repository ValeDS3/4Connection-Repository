﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Net.Http;
using Newtonsoft.Json;
using SharedModels;

namespace $safeprojectname$.Servicios
{
    public class UsuarioService
    {
        private readonly HttpClient _httpclient;

        public UsuarioService(HttpClient httpclient)
        {
            _httpclient = httpclient;
        }

        public async Task<UsuarioSH> GetUsuarioById(int idusuario)
        {
            var response = await _httpclient.GetAsync($"https://localhost:44350/api/UsuarioControlador/{idusuario}");

            if (response.IsSuccessStatusCode)
            {
                var jsonResponse = await response.Content.ReadAsStringAsync();

                return JsonConvert.DeserializeObject<UsuarioSH>(jsonResponse);
            }

            return null;

        }
    }
}
