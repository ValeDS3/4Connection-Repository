﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using NetCoreAPIMySQL.Data.Repositorio;
using NetCoreAPIMySQL.Model;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;


namespace $safeprojectname$.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class GrupoControlador : ControllerBase
    {
        private readonly IGrupoRepositorio _grupoRepositorio;
       
        public GrupoControlador (IGrupoRepositorio grupoRepositorio )
        {
            _grupoRepositorio = grupoRepositorio;
            
        }

        [HttpGet]
        public async Task<IActionResult> GetAllGrupos()
        {
            return Ok(await _grupoRepositorio.GetAllGrupos());
        }

        [HttpGet("{codigogrupo}")]
        public async Task<IActionResult> GetgrupoDetail(int codigogrupo)
        {
            return Ok(await _grupoRepositorio.GetDetailGrupos(codigogrupo));
        }

        [HttpPost ("CrearGrupo")]
        public async Task<IActionResult> CreateGrupo([FromForm] GrupoDto grupoDto)
        {
            if (grupoDto == null)
                return BadRequest("El grupo no puede ser null ");

            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            byte[] fotoBytes = null;
            if(grupoDto.Pp_Grupos!=null)
            {
                using var memoryStream = new MemoryStream();
                await grupoDto.Pp_Grupos.CopyToAsync(memoryStream);
                fotoBytes = memoryStream.ToArray();
            }

            var grupo = new Grupo
            {
                NombreGrupo = grupoDto.NombreGrupo,
                UsuarioCreador = grupoDto.UsuarioCreador,
                Descripcion = grupoDto.Descripcion,
                CodigoInvitacion = grupoDto.CodigoInvitacion,
                Pp_Grupos = fotoBytes


            };

            var created = await _grupoRepositorio.InsertGrupo(grupo);
            return Created("created", created);
        }

        [HttpPut]
        public async Task<IActionResult> UpdateGrupo([FromBody] Grupo grupo)
        {
            if (grupo == null)
                return BadRequest();
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            await _grupoRepositorio.UpdateGrupo(grupo);
            return NoContent();
        }

        [HttpDelete("{codigogrupo}")]
        public async Task<IActionResult> DeleteGrupo(int codigogrupo)
        {
            await _grupoRepositorio.DeleteGrupo(new Grupo() { CodigoGrupo= codigogrupo });
            return NoContent();

        }


    }
}

