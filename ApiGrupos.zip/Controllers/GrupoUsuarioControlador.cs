﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using NetCoreAPIMySQL.Data.Repositorio;
using NetCoreAPIMySQL.Model;

namespace $safeprojectname$.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class GrupoUsuarioControlador : ControllerBase
    {
        private readonly IGUsuarioRepositorio _igUsuarioRepositorio;

        public GrupoUsuarioControlador(IGUsuarioRepositorio igUsuarioRepositorio)
        {
            _igUsuarioRepositorio = igUsuarioRepositorio;
        }

        [HttpGet]
        public async Task<IActionResult> GetAllGrupos()
        {
            return Ok(await _igUsuarioRepositorio.GetAllGrupoUsuario());
        }

        [HttpGet("grupo/{codigogrupo}")]
        public async Task<IActionResult> GetDetailGrupo(int codigogrupo)
        {
            return Ok(await _igUsuarioRepositorio.GetDetailGrupo(codigogrupo));
        }

        [HttpGet("usuario/{idusuario}")]
        public async Task<IActionResult> GetDetailUsuario(int idusuario)
        {
            return Ok(await _igUsuarioRepositorio.GetDetailUsuario(idusuario));
        }

        [HttpPost]
        public async Task<IActionResult> CreateGrupoUsuario([FromBody] GrupoUsuario grupoU)
        {
            if (grupoU == null)
                return BadRequest();

            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            var created = await _igUsuarioRepositorio.InsertGrupoU(grupoU);
            return Created("created", created);
        }

       /* [HttpPut]
        public async Task<IActionResult> UpdateGrupoU([FromBody] GrupoUsuario grupoU)
        {
            if (grupoU == null)
                return BadRequest();
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            await _igUsuarioRepositorio.UpdateGrupoU(grupoU);
            return NoContent();
        }*/

        [HttpDelete("{codigogrupo}/ {idusuario}")]
        public async Task<IActionResult> DeleteGrupo(int codigogrupo, int idusuario)
        {
            await _igUsuarioRepositorio.DeleteGrupoU(new GrupoUsuario() { CodigoGrupo= codigogrupo ,IdUsuario=idusuario });
            return NoContent();

        }


    }
    
}
