﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using NetCoreAPIMySQL.Data.Proyecto;
using NetCoreAPIMySQL.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace $safeprojectname$.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PostEtiquetaControlador : ControllerBase
    {
        private readonly IPostEtiqueta _iposE;

        public PostEtiquetaControlador(IPostEtiqueta iposE)
        {
            _iposE = iposE;
        }

        [HttpGet]
        public async Task<IActionResult> GetAllPostEtiqueta()
        {
            return Ok(await _iposE.GetAllPostEtiqueta());
        }

        [HttpGet("post/{idpost}")]
        public async Task<IActionResult> GetPostDetails(int idpost)
        {
            return Ok(await _iposE.GetPostDetails(idpost));
        }
        [HttpGet("etiqueta/{etiqueta}")]
        public async Task<IActionResult> GetEtiquetaDetails(string etiqueta)
        {
            return Ok(await _iposE.GetEtiquetaDetails(etiqueta));
        }

        [HttpPost]
        public async Task<IActionResult> CreateEtiqueta([FromBody] PostEtiqueta postE)
        {
            if (postE == null)
                return BadRequest();

            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            var created = await _iposE.InsertEtiqueta(postE);
            return Created("created", created);
        }

        [HttpDelete("{idpost}/ {etiqueta}")]
        public async Task<IActionResult> DeleteEtiqueta(int idpost, string etiqueta)
        {
            await _iposE.DeleteEtiqueta(new PostEtiqueta() { IdPost = idpost, Etiqueta = etiqueta });
            return NoContent();

        }






    }
}
