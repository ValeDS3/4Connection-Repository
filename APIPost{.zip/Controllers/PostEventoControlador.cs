﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using NetCoreAPIMySQL.Data.Proyecto;
using NetCoreAPIMySQL.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace $safeprojectname$.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PostEventoControlador : ControllerBase
    {
        private readonly IPostEvento _postE;

        public PostEventoControlador (IPostEvento postE)
        {
            _postE = postE;
        }

        [HttpGet]
        public async Task<IActionResult> GetAllPost()
        {
            return Ok(await _postE.GetAllPost());
        }

        [HttpGet("{idpostevento}")]
        public async Task<IActionResult> GetPostDetails(int idpostevento)
        {
            return Ok(await _postE.GetPostDetails(idpostevento));
        }

        [HttpPost("CrearPostEvento")]
        public async Task<IActionResult> CreatePost([FromBody] PostEvento postE)
        {
            if (postE == null)
                return BadRequest();

            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            var created = await _postE.InsertPost(postE);
            return Created("created", created);
        }

        [HttpPut]
        public async Task<IActionResult> UpdatePost([FromBody] PostEvento postE)
        {
            if (postE == null)
                return BadRequest();
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            await _postE.UpdatePost(postE);
            return NoContent();
        }

        [HttpDelete("{idpostevento}")]
        public async Task<IActionResult> DeletePost(int idpostevento)
        {
            await _postE.DeletePost(new PostEvento() { IdPostEvento = idpostevento });
            return NoContent();

        }


    }
}
