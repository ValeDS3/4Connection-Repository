﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using NetCoreAPIMySQL.Data.Proyecto;
using NetCoreAPIMySQL.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace $safeprojectname$.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EventoUsuarioControlador : ControllerBase
    {
        private readonly IEUsuarioRepositorio _ieurepos;

        public EventoUsuarioControlador(IEUsuarioRepositorio ieurepos)
        {
            _ieurepos = ieurepos;
        }

        [HttpGet]
        public async Task<IActionResult> GetAllEventoUsuario()
        {
            return Ok(await _ieurepos.GetAllEventoUsuario());
        }

        [HttpGet("evento/{idevento}")]
        public async Task<IActionResult> GetEventoDetails(int idevento)
        {
            return Ok(await _ieurepos.GetEventoDetails(idevento));
        }

        [HttpGet("usuario/{idusuario}")]
        public async Task<IActionResult> GetusuarioDetails(int idusuario)
        {
            return Ok(await _ieurepos.GetUsuarioDetails(idusuario));
        }

        [HttpPost]
        public async Task<IActionResult> CreateEventoUsuario([FromBody] EventoUsuario eventoU)
        {
            if (eventoU == null)
                return BadRequest();

            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            var created = await _ieurepos.InsertEventoUsuario(eventoU);
            return Created("created", created);
        }

        [HttpDelete("{idevento}/ {idusuario}")]
        public async Task<IActionResult> DeleteEventousuario(int idevento, int idusuario)
        {
            await _ieurepos.DeleteEventoUsuario(new EventoUsuario() { IdEvento = idevento, IdUsuario = idusuario });
            return NoContent();

        }

    }

}
