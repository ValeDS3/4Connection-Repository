﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using NetCoreAPIMySQL.Data.Proyecto;
using NetCoreAPIMySQL.Model;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace $safeprojectname$.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PostImagenControlador : ControllerBase
    {
        private readonly IPostImagenRepositoriocs postImagenRepositorio;

        public PostImagenControlador(IPostImagenRepositoriocs postImagen)
        {
            postImagenRepositorio = postImagen;
        }

        [HttpGet]
        public async Task<IActionResult> GetAllPostImagen()
        {
            return Ok(await postImagenRepositorio.GetAllPostImagen());
        }

        [HttpGet("{idpost}")]
        public async Task<IActionResult> GetImagenPost(int idpost)
        {
            var postImagen = await postImagenRepositorio.GetImagenPost(idpost);
            if (postImagen == null || postImagen.Imagen == null)
            {
                return NotFound();
            }
            // Devuelve la imagen directamente en lugar de un objeto JSON
            return File(postImagen.Imagen, "image/jpeg");
        }

        [HttpPost("CrearImagen")]
        public async Task<IActionResult> InsertImagen([FromForm] PostImagenDto postImagenDto)
        {
            if (postImagenDto == null)
                return BadRequest("La imagen no puede ser null.");

            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            byte[] fotoBytes = null;
            if (postImagenDto.Imagen != null)
            {
                using var memoryStream = new MemoryStream();
                await postImagenDto.Imagen.CopyToAsync(memoryStream);
                fotoBytes = memoryStream.ToArray();
            }

            var postImagen = new PostImagen
            {
                IdPost = postImagenDto.IdPost,
                Imagen = fotoBytes,
            };

            int idImagen = await postImagenRepositorio.InsertImagen(postImagen);
            return CreatedAtAction(nameof(InsertImagen), new { idimagen = idImagen }, new { id = idImagen });
        }


        [HttpPut]
        public async Task<IActionResult> UpdateImagen([FromBody] PostImagen postImagen)
        {
            if (postImagen == null)
                return BadRequest();
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            await postImagenRepositorio.UpdateImagen(postImagen);
            return NoContent();
        }

        [HttpDelete("{idImagen}")]
        public async Task<IActionResult> DeleteImagen(int idimagen)
        {
            await postImagenRepositorio.DeleteImagen(new PostImagen() { IdImagen = idimagen });
            return NoContent();

        }
    }
}
