﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using NetCoreAPIMySQL.Data.Proyecto;
using NetCoreAPIMySQL.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace $safeprojectname$.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PostPublicoControlador : ControllerBase
    {
        private readonly IPostPublicoRepositorio _postP;

        public PostPublicoControlador (IPostPublicoRepositorio postP)
        {
            _postP = postP;
        }

        [HttpGet]
        public async Task<IActionResult> GetAllPost()
        {
            return Ok(await _postP.GetAllPost());
        }


        [HttpGet("{idpostpublico}")]
        public async Task<IActionResult> GetPostDetails(int idpostpublico)
        {
            return Ok(await _postP.GetPostDetails(idpostpublico));
        }

        [HttpPost ("CrearPostPublico")]
        public async Task<IActionResult> CreatePost([FromBody] PostPublico postP)
        {
            if (postP == null)
                return BadRequest();

            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            var created = await _postP.InsertPost(postP);
            return Created("created", created);
        }

        [HttpDelete("{idpostP}")]
        public async Task<IActionResult> DeletePost(int idpostP)
        {
            await _postP.DeletePost(new PostPublico() { IdPostPublico = idpostP });
            return NoContent();

        }

        [HttpPut]
        public async Task<IActionResult> UpdatePost([FromBody] PostPublico postP)
        {
            if (postP == null)
                return BadRequest();
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            await _postP.UpdatePost(postP);
            return NoContent();
        }



    }
}
