﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using NetCoreAPIMySQL.Data.Proyecto;
using NetCoreAPIMySQL.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace $safeprojectname$.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PostControlador : ControllerBase
    {

        private readonly IPostRepositorio _postRepositorio;

        public PostControlador(IPostRepositorio postRepositorio)
        {
            _postRepositorio = postRepositorio;
        }

        [HttpGet]
        public async Task<IActionResult> GetAllPost()
        {
            return Ok(await _postRepositorio.GetAllPost());
        }

        [HttpGet("{idpost}")]
        public async Task<IActionResult> GetPosytDetails(int idpost)
        {
            return Ok(await _postRepositorio.GetPostDetails(idpost));
        }

        [HttpPost]
        public async Task<IActionResult> CreatePost([FromBody] Post post)
        {
            if (post == null)
                return BadRequest();

            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            var created = await _postRepositorio.InsertPost(post);
            return Created("created", created);
        }

        [HttpPut]
        public async Task<IActionResult> UpdatePost ([FromBody] Post post)
        {
            if (post == null)
                return BadRequest();
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            await _postRepositorio.UpdatePost(post);
            return NoContent();
        }

        [HttpDelete("{idpost}")]
        public async Task<IActionResult> DeletePost(int idpost)
        {
            await _postRepositorio.DeletePost(new Post() { IdPost = idpost });
            return NoContent();

        }

    }
}
