﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using NetCoreAPIMySQL.Data.Proyecto;
using NetCoreAPIMySQL.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace $safeprojectname$.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PostGrupoControlador : ControllerBase
    {
        private readonly IPostGrupo _postG;

        public PostGrupoControlador(IPostGrupo postG)
        {
            _postG = postG;
        }

        [HttpGet]
        public async Task<IActionResult> GetAllPostGrupo()
        {
            return Ok(await _postG.GetAllPostGrupo());
        }

        [HttpGet("{idpostG}")]
        public async Task<IActionResult> GetPostDetails(int idpostG)
        {
            return Ok(await _postG.GetPostDetails(idpostG));
        }

        [HttpPost]
        public async Task<IActionResult> CreatePost([FromBody] PostGrupo postG )
        {
            if (postG == null)
                return BadRequest();

            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            var created = await _postG.InsertPostGrupo(postG);
            return Created("created", created);
        }

        [HttpDelete("{idpostG}")]
        public async Task<IActionResult> DeletePost(int idpostG)
        {
            await _postG.DeletePostGrupo(new PostGrupo() { IdPostGrupo = idpostG });
            return NoContent();

        }

        [HttpPut]
        public async Task<IActionResult> UpdatePostGrupo([FromBody] PostGrupo postG)
        {
            if (postG == null)
                return BadRequest();
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            await _postG.UpdatePostGrupo(postG);
            return NoContent();
        }
    }
}
