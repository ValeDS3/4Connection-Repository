﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using NetCoreAPIMySQL.Data.Proyecto;
using NetCoreAPIMySQL.Model;

namespace $safeprojectname$.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EventoControlador : ControllerBase
    {
        private readonly IEventorepositorio _eventorepositorio;

        public EventoControlador(IEventorepositorio eventorepositorio)
        {
            _eventorepositorio = eventorepositorio;
        }

        [HttpGet]
        public async Task<IActionResult> GetAllEvento()
        {
            return Ok(await _eventorepositorio.GetAllEvento());
        }

        [HttpGet("{idevento}")]
        public async Task<IActionResult> GetEventoDetails(int idevento)
        {
            return Ok(await _eventorepositorio.GetEventoDetails(idevento));
        }

        [HttpPost]
        public async Task<IActionResult> CreateEvento([FromBody] Evento evento)
        {
            if (evento == null)
                return BadRequest();

            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            var created = await _eventorepositorio.InsertEvento(evento);
            return Created("created", created);
        }

        [HttpPut]
        public async Task<IActionResult> UpdateEvento([FromBody] Evento evento)
        {
            if (evento == null)
                return BadRequest();
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            await _eventorepositorio.UpdateEvento(evento);
            return NoContent();
        }

        [HttpDelete("{idevento}")]
        public async Task<IActionResult> DeleteEvento(int idevento)
        {
            var evento = await _eventorepositorio.GetEventoDetails(idevento);
            if (evento == null)
            {
                return NotFound();
            }
            return Ok(evento);

        }

       
    }
}
