﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using NetCoreAPIMySQL.Data.Repositorio;
using NetCoreAPIMySQL.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace $safeprojectname$.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PassControlador : ControllerBase
    {
        private readonly IPassRepositoriocs _passRepositorio;

        public PassControlador(IPassRepositoriocs passRepositorio)
        {
            _passRepositorio = passRepositorio;
        }

        [HttpGet]
        public async Task<IActionResult> GetAllPass()
        {
            return Ok(await _passRepositorio.GetAllPass());
        }

        [HttpGet("{idusuario}")]
        public async Task<IActionResult> GetPass(int idusuario)
        {
            return Ok(await _passRepositorio.GetPass(idusuario));
        }

        [HttpPost ("CreatePass")]
        public async Task<IActionResult> CreatePass([FromBody] TipoPass pass)
        {
            if (pass==null)
                return BadRequest("El objeto recibido es nulo.");
            if (string.IsNullOrEmpty(pass.HashPass))
            {
                return BadRequest("El campo 'pass' es nulo o vacío.");
            }

            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            var created = await _passRepositorio.InsertPass(pass);
            return Created("created", created);
        }

        [HttpPut]
        public async Task<IActionResult> UpdatePass([FromBody] TipoPass pass)
        {
            if (pass ==null)
                return BadRequest();
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            await _passRepositorio.UpdatePass(pass);
            return NoContent();
        }

        [HttpDelete("{idusuario}")]
        public async Task<IActionResult> DeletePass(int idusuario)
        {
            await _passRepositorio.DeletePass(new TipoPass() { IdUsuario = idusuario });
            return NoContent();

        }


    }
}
