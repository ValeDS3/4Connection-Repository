﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using NetCoreAPIMySQL.Data.Repositorio;
using NetCoreAPIMySQL.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using SharedModels;
using System.IO;

namespace $safeprojectname$.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UsuarioControlador : ControllerBase
    {
        private readonly IUsuarioRepositorio _usuarioRepositorio;

        public UsuarioControlador(IUsuarioRepositorio usuarioRepositorio)
        {
            _usuarioRepositorio = usuarioRepositorio;
        }

        [HttpGet]
        public async Task<IActionResult> GetAllUsuario()
        {
            return Ok(await _usuarioRepositorio.GetAllUsuario());
        }

        [HttpGet("{idusuario}")]
        public async Task<IActionResult> GetUsuarioDetails(int idusuario)
        {
            return Ok(await _usuarioRepositorio.GetUsuarioDetails(idusuario));
        }

        [HttpPost("CrearUsuario")]
        public async Task<IActionResult> CreateUsuario([FromForm] UsuarioDto usuarioDto)
        {
            if (usuarioDto==null)
                return BadRequest("El objeto usuario no puede ser null.");

            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            byte[] fotoBytes = null;
            if(usuarioDto.FotoPerfil !=null)
            {
                using var memoryStream = new MemoryStream();
                await usuarioDto.FotoPerfil.CopyToAsync(memoryStream);
                fotoBytes = memoryStream.ToArray();
            }

            var usuario = new Usuario
            {
                Nombre = usuarioDto.Nombre,
                FechaNac = usuarioDto.FechaNac,
                Descripcion = usuarioDto.Descripcion,
                FotoPerfil = fotoBytes, // Asignamos la imagen como bytes
                Pass = usuarioDto.Pass
            };


            int idUsuario = await _usuarioRepositorio.InsertUsuario(usuario);
            return CreatedAtAction(nameof(CreateUsuario), new { id = idUsuario }, new { id = idUsuario });
        }

        [HttpPut]
        public async Task<IActionResult> UpdateUsuario([FromBody] Usuario usuario)
        {
            if (usuario ==null)
                return BadRequest();
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            await _usuarioRepositorio.UpdateUsuario(usuario);
            return NoContent();
        }

        [HttpDelete("{idusuario}")]
        public async Task<IActionResult> DeleteUsuario(int idusuario)
        {
            await _usuarioRepositorio.DeleteUsuario(new Usuario() { IdUsuario = idusuario });
            return NoContent();

        }


    }
}
