﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using NetCoreAPIMySQL.Data.Repositorio;
using NetCoreAPIMySQL.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using SharedModels;

namespace $safeprojectname$.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UsuarioControlador : ControllerBase
    {
        private readonly IUsuarioRepositorio _usuarioRepositorio;

        public UsuarioControlador(IUsuarioRepositorio usuarioRepositorio)
        {
            _usuarioRepositorio = usuarioRepositorio;
        }

        [HttpGet]
        public async Task<IActionResult> GetAllUsuario()
        {
            return Ok(await _usuarioRepositorio.GetAllUsuario());
        }

        [HttpGet("{idusuario}")]
        public async Task<IActionResult> GetUsuarioDetails(int idusuario)
        {
            return Ok(await _usuarioRepositorio.GetUsuarioDetails(idusuario));
        }

        [HttpPost]
        public async Task<IActionResult> CreateUsuario([FromBody] Usuario usuario)
        {
            if (usuario==null)
                return BadRequest("El objeto usuario no puede ser null.");

            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            var created = await _usuarioRepositorio.InsertUsuario(usuario);
            return Created("created", created);
        }

        [HttpPut]
        public async Task<IActionResult> UpdateUsuario([FromBody] Usuario usuario)
        {
            if (usuario ==null)
                return BadRequest();
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            await _usuarioRepositorio.UpdateUsuario(usuario);
            return NoContent();
        }

        [HttpDelete("{idusuario}")]
        public async Task<IActionResult> DeleteUsuario(int idusuario)
        {
            await _usuarioRepositorio.DeleteUsuario(new Usuario() { IdUsuario = idusuario });
            return NoContent();

        }


    }
}
