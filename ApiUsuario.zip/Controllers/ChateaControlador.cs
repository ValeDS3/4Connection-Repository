﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using NetCoreAPIMySQL.Data.Repositorio;
using NetCoreAPIMySQL.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace $safeprojectname$.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ChateaControlador : ControllerBase
    {
        private readonly IChateaRepositorio _chateaRepositorio;

        public ChateaControlador(IChateaRepositorio chateaRepositorio)
        {
            _chateaRepositorio = chateaRepositorio;
        }

        [HttpGet]
        public async Task<IActionResult> GetAllChat()
        {
            return Ok(await _chateaRepositorio.GetAllChat());
        }

        [HttpGet("{emisor}")]
        public async Task<IActionResult> GetChatDetails(int emisor)
        {
            return Ok(await _chateaRepositorio.GetChatDetails(emisor));
        }

        [HttpPost]
        public async Task<IActionResult> CreateChat([FromBody] Chatea chatea)
        {
            if (chatea == null)
                return BadRequest();

            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            var created = await _chateaRepositorio.InsertChat(chatea);
            return Created("created", created);
        }

        [HttpDelete("{emisor}/{receptor}/{fecha}")]
        public async Task<IActionResult> DeletePass(int emisor, int receptor, string fecha)
        {
            await _chateaRepositorio.DeleteChat(new Chatea() {Emisor=emisor, Receptor= receptor, Fecha=fecha });
            return NoContent();

        }
    }
}
