﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NetCoreAPIMySQL.Model
{
    public class Post
    {
        public int Id { get; set; }
        public string Texto { get; set; }
        public string Fec_horahapub { get; set; }
    }
}
