﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Dapper;
using MySql.Data.MySqlClient;
using NetCoreAPIMySQL.Model;

namespace NetCoreAPIMySQL.Data.Repositorio
{
    public class PostRepositorio : IPostRepositorio
    {
        private MySQLConfiguration _connectionString;
        public PostRepositorio(MySQLConfiguration connectionString)
        {
            _connectionString = connectionString;
        }
        protected MySqlConnection dbConnection()
        {
            return new MySqlConnection(_connectionString.ConnectionString);
        }

        public async Task<IEnumerable<Post>> GetAllPost()
        {
            var db = dbConnection();
            var sql = @" SELECT id, texto, fec_horahapub
                        FROM post";
            return await db.QueryAsync<Post>(sql, new { });
        }

        public async Task<bool> InsertPost(Post post)
        {
            var db = dbConnection();
            var sql = @" INSERT INTO post (texto, fec_horahapub)
                         VALUES (@Texto, CURRENT_TIMESTAMP)";
            var result = await db.ExecuteAsync(sql, new { Texto = post.Texto }) ;
            return result > 0;
        }    

        public async Task<bool> UpdatePost(Post post)
        {
            var db = dbConnection();
            var sql = @"UPDATE post
                        SET texto=@Texto
                        WHERE id=@Id ";
            var result = await db.ExecuteAsync(sql, new { Texto=post.Texto, Id=post.Id});
            return result > 0;
        }

        public async  Task<bool> DeletePost(Post post)
        {
            var db = dbConnection();
            var sql = @"DELETE
                        FROM post
                        WHERE id=@Id";
            var result =await db.ExecuteAsync(sql, new { Id = post.Id });
            return result > 0;
        }
            public async Task<Post> GetPostDetails(int id)
        {
            var db = dbConnection();
            var sql = @" SELECT id, texto, fec_horahapub
                        FROM post
                        WHERE id=@Id";
            return await db.QueryFirstOrDefaultAsync<Post>(sql, new { Id = id });
            
        }
    }
}
