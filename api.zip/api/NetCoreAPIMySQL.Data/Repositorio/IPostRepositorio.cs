﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NetCoreAPIMySQL.Model;
namespace NetCoreAPIMySQL.Data.Repositorio
{
   public  interface IPostRepositorio
    {
        Task<IEnumerable<Post>> GetAllPost();
        Task<Post> GetPostDetails(int id);
        Task<bool> InsertPost(Post post);
        Task<bool> UpdatePost(Post post);
        Task<bool> DeletePost(Post post);
    }
}
