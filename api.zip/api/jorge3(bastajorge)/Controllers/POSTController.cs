﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using NetCoreAPIMySQL.Data.Repositorio;
using NetCoreAPIMySQL.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace jorge3_bastajorge_.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class POSTController : ControllerBase
    {
        private readonly IPostRepositorio _postRepositorio;

        public POSTController(IPostRepositorio postRepositorio)
        {
            _postRepositorio = postRepositorio;
        }

        [HttpGet]
        public async Task<IActionResult> GetAllPost()
        {
            return Ok(await _postRepositorio.GetAllPost());
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> GetPostDetails(int id)
        {
            return Ok(await _postRepositorio.GetPostDetails(id));
        }

        [HttpPost]
        public async Task<IActionResult> InsertPost([FromBody] Post post)
        {
            if (post == null)
                return BadRequest();

            if (!ModelState.IsValid)
                return BadRequest(ModelState);
            var created = await _postRepositorio.InsertPost(post);
            return Created("created", created);
        }

        [HttpPut]
        public async Task<IActionResult> UpdatePost([FromBody] Post post)
        {
            if (post == null)
                return BadRequest();

            if (ModelState.IsValid)
                return BadRequest(ModelState);

            await _postRepositorio.UpdatePost(post);
            return NoContent();

        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> DeletePost(int id)
        {
            await _postRepositorio.DeletePost(new Post() { Id = id });
            return NoContent();
        }


    }
}
